# THE FALL OF CONSTANTINOPLE — 1453 (Remotion, 60 s, 1080×1920, 30 fps)

Semua visual adalah SVG/React prosedural (tanpa gambar eksternal). Audio musik + SFX dibuat prosedural
oleh `scripts/gen-audio.mjs` (offline, gratis). Narasi memakai `public/audio/narration.mp3` (file Anda).

## Perintah (di GitHub Codespaces)

```bash
# sekali saja: library sistem untuk Chrome headless Remotion
sudo apt-get update && sudo apt-get install -y libnss3 libdbus-1-3 libatk1.0-0 libasound2t64 \
  libxrandr2 libxkbcommon-dev libxfixes3 libxcomposite1 libxdamage1 libgbm-dev libcups2 libatk-bridge2.0-0
# (jika libasound2t64 tidak ditemukan, pakai libasound2)

npm install
npm run typecheck        # opsional
npm run dev              # Remotion Studio (pratinjau interaktif)
npm run render:fast      # -> out/preview.mp4 (540x960, CRF 30)
npm run render           # -> out/konstantinopel-1453.mp4 (1080x1920, 30fps, H.264)
```

Jika render kehabisan memori, turunkan `--concurrency=2` menjadi `1` di `package.json`.

## Struktur
- `src/timing.json` — SATU sumber timing: awal/akhir adegan, event SFX, jendela kalimat narasi.
- `src/scenes/` — Opening, Sultan, Cannons, Ships, FinalAssault, Conquest, Ending.
- `src/components/` — Character (kepala bulat, tangan/kaki lidi, 4 kostum), Soldier (pasukan), Camera (keyframe + shake + parallax),
  Background, Props, ParticleSystem, Transitions, AnimatedText, Captions.
- `src/audio/AudioManager.tsx` — narasi > musik (ducking) > SFX.

## Mengganti narasi
Timpa `public/audio/narration.mp3` (maks 60 dtk). Caption per kata diperkirakan dari jendela kalimat di
`src/timing.json` (`narration[].s/e`, detik) — sesuaikan angka itu bila narasi baru berbeda.

## Catatan
- Timing adegan digeser dari brief agar sinkron dengan narasi 47 dtk (jeda kalimat dideteksi dari mp3).
- Musik/SFX diregenerasi dengan `FORCE_AUDIO=1 npm run gen:audio` bila `timing.json` diubah.
