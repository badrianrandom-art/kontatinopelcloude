import {Easing, interpolate} from 'remotion';
import timing from './timing.json';

export const FPS = timing.fps;
export const W = 1080;
export const H = 1920;
export const sec = (s: number) => Math.round(s * FPS);

export const INK = '#17120f';
export const CREAM = '#fbf6ea';
export const GOLD = '#e8b83a';
export const STONE = '#d9c7a3';

export const ease = (
  f: number, a: number, b: number, from = 0, to = 1,
  e: (t: number) => number = Easing.inOut(Easing.cubic),
) => interpolate(f, [a, b], [from, to], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: e});

const hex = (c: string) => [1, 3, 5].map((i) => parseInt(c.slice(i, i + 2), 16));
export const lerpColor = (a: string, b: string, t: number) => {
  const A = hex(a), B = hex(b);
  const k = Math.min(1, Math.max(0, t));
  return `rgb(${A.map((v, i) => Math.round(v + (B[i] - v) * k)).join(',')})`;
};
