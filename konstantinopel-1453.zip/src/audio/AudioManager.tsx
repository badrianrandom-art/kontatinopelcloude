import React from 'react';
import {Audio, interpolate, staticFile} from 'remotion';
import timing from '../timing.json';

const FPS = timing.fps;
const nStart = timing.narration[0].s * FPS;
const nEnd = timing.narration[timing.narration.length - 1].e * FPS;

/**
 * Layers: narration (loud) > music (ducked while narrator speaks) > sfx.
 * To use another voice-over, just replace public/audio/narration.mp3 (keep it <= 60s).
 */
export const AudioManager: React.FC = () => (
  <>
    <Audio src={staticFile('audio/music.wav')}
      volume={(f: number) => interpolate(f, [nStart - 20, nStart + 10, nEnd - 10, nEnd + 40], [0.75, 0.3, 0.3, 0.85], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'})} />
    <Audio src={staticFile('audio/sfx.wav')} volume={0.62} />
    <Audio src={staticFile('audio/narration.mp3')} volume={1} />
  </>
);
