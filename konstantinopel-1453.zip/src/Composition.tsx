import React from 'react';
import {AbsoluteFill, Sequence} from 'remotion';
import {Opening} from './scenes/Opening';
import {Sultan} from './scenes/Sultan';
import {Cannons} from './scenes/Cannons';
import {Ships} from './scenes/Ships';
import {FinalAssault} from './scenes/FinalAssault';
import {Conquest} from './scenes/Conquest';
import {Ending} from './scenes/Ending';
import {FadeOut, Grade} from './components/Transitions';
import {Captions} from './components/Captions';
import {AudioManager} from './audio/AudioManager';
import {sec} from './theme';
import timing from './timing.json';
import './styles/global.css';

const SC = timing.scenes;
const LIST: {key: keyof typeof SC; C: React.FC}[] = [
  {key: 'opening', C: Opening}, {key: 'sultan', C: Sultan}, {key: 'cannons', C: Cannons}, {key: 'ships', C: Ships},
  {key: 'assault', C: FinalAssault}, {key: 'conquest', C: Conquest}, {key: 'ending', C: Ending},
];
const XFADE = 10;

export const Konstantinopel: React.FC = () => {
  const items = LIST.map(({key, C}, i) => {
    const from = sec(SC[key][0]);
    const next = i < LIST.length - 1 ? sec(SC[LIST[i + 1].key][0]) : sec(SC[key][1]);
    const dur = next - from;
    const last = i === LIST.length - 1;
    return {key, C, from, dur, last};
  });
  // Earlier scenes are rendered on top and dissolve out over the next scene (which starts on time underneath).
  return (
    <AbsoluteFill style={{backgroundColor: '#000'}}>
      {[...items].reverse().map(({key, C, from, dur, last}) => (
        <Sequence key={key} from={from} durationInFrames={last ? dur : dur + XFADE} name={key}>
          {last ? <C /> : <FadeOut from={dur} dur={XFADE}><C /></FadeOut>}
        </Sequence>
      ))}
      <Grade />
      <Captions />
      <AudioManager />
    </AbsoluteFill>
  );
};
