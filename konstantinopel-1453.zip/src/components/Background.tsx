import React from 'react';
import {random, useCurrentFrame} from 'remotion';
import {Flag, Emblem} from './Flag';
import {GOLD, INK, lerpColor} from '../theme';

export const Sky: React.FC<{id: string; stops: [number, string][]; top?: number; bottom?: number}> = ({id, stops, top = 0, bottom = 1100}) => (
  <g>
    <defs>
      <linearGradient id={id} gradientUnits="userSpaceOnUse" x1="0" y1={top} x2="0" y2={bottom}>
        {stops.map(([o, c], i) => (<stop key={i} offset={o} stopColor={c} />))}
      </linearGradient>
    </defs>
    <rect x={-2400} y={-2400} width={7000} height={bottom + 2400 + 600} fill={`url(#${id})`} />
  </g>
);

export const Sun: React.FC<{x: number; y: number; r?: number}> = ({x, y, r = 100}) => (
  <g>
    <circle cx={x} cy={y} r={r * 2.4} fill="url(#sunG)" opacity={0.55} />
    <circle cx={x} cy={y} r={r} fill="#fff6cf" />
  </g>
);

export const Clouds: React.FC<{y: number; n?: number; speed?: number; seed?: number; scale?: number; x0?: number; span?: number; tint?: string; opacity?: number}> = ({
  y, n = 5, speed = 0.4, seed = 1, scale = 1, x0 = -500, span = 2400, tint = '#b9cfe8', opacity = 1,
}) => {
  const f = useCurrentFrame();
  return (
    <g opacity={opacity}>
      {Array.from({length: n}).map((_, i) => {
        const bx = x0 + ((random(`c${seed}${i}`) * span + f * speed) % span);
        const by = y + (random(`cy${seed}${i}`) - 0.5) * 220;
        const s = scale * (0.7 + random(`cs${seed}${i}`) * 0.9);
        return (
          <g key={i} transform={`translate(${bx} ${by}) scale(${s})`}>
            <ellipse cx={0} cy={22} rx={130} ry={26} fill={tint} />
            <ellipse cx={0} cy={4} rx={125} ry={36} fill="#fff" />
            <circle cx={-52} cy={-22} r={46} fill="#fff" />
            <circle cx={12} cy={-44} r={62} fill="#fff" />
            <circle cx={72} cy={-18} r={44} fill="#fff" />
            <ellipse cx={20} cy={20} rx={95} ry={14} fill={tint} opacity={0.5} />
          </g>
        );
      })}
    </g>
  );
};

export const Hills: React.FC<{y: number; amp?: number; color: string; seed?: number; x0?: number; x1?: number; shade?: string}> = ({
  y, amp = 60, color, seed = 1, x0 = -1600, x1 = 3600, shade,
}) => {
  const pts: string[] = [];
  for (let x = x0; x <= x1; x += 40) {
    pts.push(`${x} ${y - (Math.sin(x * 0.004 + seed) * amp + Math.sin(x * 0.011 + seed * 2) * amp * 0.4)}`);
  }
  return (
    <g>
      <path d={`M${x0} ${y + 1800} L${pts.join(' L')} L${x1} ${y + 1800} Z`} fill={color} stroke={INK} strokeWidth={4} strokeOpacity={0.35} />
      {shade && <path d={`M${x0} ${y + 1800} L${pts.join(' L')} L${x1} ${y + 1800} Z`} fill={shade} opacity={0.25} />}
    </g>
  );
};

export const Crenels: React.FC<{x: number; y: number; w: number; tw?: number; th?: number}> = ({x, y, w, tw = 34, th = 30}) => {
  const n = Math.floor(w / (tw * 2));
  return (
    <g>
      {Array.from({length: n + 1}).map((_, i) => (
        <rect key={i} x={x + i * tw * 2} y={y - th} width={tw} height={th + 2} fill="#cdb98f" stroke={INK} strokeWidth={4} />
      ))}
    </g>
  );
};

export const Tower: React.FC<{
  x: number; y: number; w: number; h: number; roof?: string; flag?: {color: string; emblem: Emblem}; slack?: number;
}> = ({x, y, w, h, roof, flag, slack = 1}) => (
  <g>
    <rect x={x} y={y - h} width={w} height={h} fill="url(#brick)" stroke={INK} strokeWidth={5} />
    <rect x={x} y={y - h} width={w} height={h} fill="url(#shadeL)" />
    <rect x={x - 10} y={y - h - 14} width={w + 20} height={22} fill="#cdb98f" stroke={INK} strokeWidth={5} />
    {!roof && <Crenels x={x - 10} y={y - h - 14} w={w + 20} tw={Math.max(14, w / 6)} th={26} />}
    <path d={`M${x + w / 2 - 14} ${y - h * 0.55} v-34 a14 14 0 0 1 28 0 v34 z`} fill="#3a2a22" stroke={INK} strokeWidth={3} />
    <path d={`M${x + w / 2 - 10} ${y - h * 0.25} v-26 a10 10 0 0 1 20 0 v26 z`} fill="#3a2a22" stroke={INK} strokeWidth={3} />
    {roof && (
      <polygon points={`${x - 12},${y - h - 8} ${x + w / 2},${y - h - 8 - w * 0.85} ${x + w + 12},${y - h - 8}`} fill={roof} stroke={INK} strokeWidth={5} strokeLinejoin="round" />
    )}
    {flag && <Flag x={x + w / 2} y={y - h - (roof ? w * 0.85 + 90 : 90)} w={Math.max(110, w * 1.1)} h={Math.max(72, w * 0.7)} color={flag.color} emblem={flag.emblem} pole={Math.max(110, w * 1.1) * 1.1} seed={x} slack={slack} />}
  </g>
);

export const Wall: React.FC<{x: number; y: number; w: number; h: number; crack?: number; crackX?: number; breach?: number; breachX?: number; jitter?: number}> = ({
  x, y, w, h, crack = 0, crackX = 0, breach = 0, breachX = 0, jitter = 0,
}) => {
  const bw = breach * 300;
  const cx = breachX;
  const crackPath = `M${crackX} ${y - h * 0.92} l-24 60 l30 40 l-34 56 l28 52 l-18 50 l20 40`;
  const crackPath2 = `M${crackX - 24} ${y - h * 0.92 + 60} l-60 20 l-26 36 M${crackX - 28} ${y - h * 0.62} l50 14 l34 40`;
  return (
    <g transform={`translate(${jitter} 0)`}>
      <rect x={x} y={y - h} width={w} height={h} fill="url(#brick)" stroke={INK} strokeWidth={6} />
      <rect x={x} y={y - h} width={w} height={h} fill="url(#shadeL)" />
      <rect x={x - 6} y={y - h - 12} width={w + 12} height={22} fill="#cdb98f" stroke={INK} strokeWidth={5} />
      <Crenels x={x - 6} y={y - h - 12} w={w + 12} />
      {Array.from({length: Math.floor(w / 240)}).map((_, i) => (
        <path key={i} d={`M${x + 120 + i * 240} ${y - h * 0.55} v-46 a12 12 0 0 1 24 0 v46z`} fill="#3a2a22" stroke={INK} strokeWidth={3} />
      ))}
      {bw > 0 && (
        <g>
          <polygon points={`${cx - bw / 2},${y} ${cx - bw / 2 + 14},${y - h * 0.45} ${cx - bw * 0.25},${y - h * 0.72} ${cx},${y - h * 0.6} ${cx + bw * 0.28},${y - h * 0.86} ${cx + bw / 2 - 14},${y - h * 0.42} ${cx + bw / 2},${y}`} fill="#8a6d57" stroke={INK} strokeWidth={5} />
          {[0, 1, 2, 3, 4, 5, 6].map((i) => (
            <polygon key={i} points={`${cx - bw / 2 + i * (bw / 6.5)},${y + 6} ${cx - bw / 2 + i * (bw / 6.5) + 30},${y - 36 - (i % 3) * 14} ${cx - bw / 2 + i * (bw / 6.5) + 64},${y + 6}`} fill={i % 2 ? '#b8a27a' : '#9c8764'} stroke={INK} strokeWidth={4} />
          ))}
        </g>
      )}
      {crack > 0 && (
        <g fill="none" stroke={INK} strokeWidth={7} strokeLinecap="round" strokeLinejoin="round">
          <path d={crackPath} strokeDasharray={420} strokeDashoffset={420 * (1 - crack)} />
          <path d={crackPath2} strokeDasharray={260} strokeDashoffset={260 * (1 - Math.max(0, crack * 1.4 - 0.4))} strokeWidth={5} />
        </g>
      )}
    </g>
  );
};

export const City: React.FC<{x: number; y: number; s?: number; haze?: number; hazeColor?: string; topper?: 'cross' | 'none'; flags?: 'ottoman' | 'byz' | 'none'; flagSlack?: number}> = ({
  x, y, s = 1, haze = 0, hazeColor = '#f5d3a8', topper = 'cross', flags = 'none', flagSlack = 1,
}) => {
  const mix = (c: string) => lerpColor(c, hazeColor, haze);
  const houses = Array.from({length: 30}).map((_, i) => {
    const w = 52, h = 46 + random(`h${i}`) * 80;
    return {x: -900 + i * 61 + (random(`hx${i}`) - 0.5) * 8, w, h, wall: i % 3 === 0 ? '#e7cfa6' : i % 3 === 1 ? '#dcb98a' : '#efdcba', roof: i % 2 ? '#b0553a' : '#9a4a34'};
  });
  const dome = (cx: number, base: number, rx: number, ry: number, col: string) => (
    <g>
      <ellipse cx={cx} cy={base} rx={rx} ry={ry} fill={mix(col)} stroke={INK} strokeWidth={5} strokeOpacity={0.9} />
      <rect x={cx - rx} y={base} width={rx * 2} height={6} fill={mix(col)} />
    </g>
  );
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`}>
      <rect x={-1000} y={-6} width={2000} height={200} fill={mix('#c9b48a')} />
      {houses.map((h, i) => (
        <g key={i}>
          <rect x={h.x} y={-h.h} width={h.w} height={h.h} fill={mix(h.wall)} stroke={INK} strokeWidth={3} strokeOpacity={0.5} />
          <polygon points={`${h.x - 4},${-h.h} ${h.x + h.w / 2},${-h.h - 24} ${h.x + h.w + 4},${-h.h}`} fill={mix(h.roof)} stroke={INK} strokeWidth={3} strokeOpacity={0.5} />
          <rect x={h.x + 18} y={-h.h + 16} width={14} height={20} rx={7} fill={mix('#5b4638')} />
        </g>
      ))}
      {/* secondary churches */}
      <rect x={-640} y={-170} width={90} height={170} fill={mix('#e9d4ae')} stroke={INK} strokeWidth={3} strokeOpacity={0.5} />
      {dome(-595, -170, 60, 66, '#9aa4b0')}
      <rect x={520} y={-190} width={100} height={190} fill={mix('#e9d4ae')} stroke={INK} strokeWidth={3} strokeOpacity={0.5} />
      {dome(570, -190, 66, 72, '#9aa4b0')}
      {/* Hagia Sophia */}
      <rect x={-210} y={-190} width={420} height={190} fill={mix('#e3c99c')} stroke={INK} strokeWidth={4} strokeOpacity={0.6} />
      {[-230, 190].map((bx) => (<rect key={bx} x={bx} y={-250} width={40} height={250} fill={mix('#d9bb8c')} stroke={INK} strokeWidth={4} strokeOpacity={0.6} />))}
      {dome(-170, -190, 100, 90, '#8f9aa6')}
      {dome(170, -190, 100, 90, '#8f9aa6')}
      {dome(0, -230, 170, 150, '#a2adb9')}
      {Array.from({length: 7}).map((_, i) => (<rect key={i} x={-130 + i * 40} y={-250} width={14} height={26} rx={7} fill={mix('#5b4638')} />))}
      {topper === 'cross' && (<g stroke={INK} strokeWidth={3} fill={GOLD}><rect x={-4} y={-420} width={8} height={44} /><rect x={-16} y={-408} width={32} height={8} /></g>)}
      {flags !== 'none' && [-230, 190].map((bx, i) => (
        <Flag key={bx} x={bx + 20} y={-420 + (i ? 20 : 0)} w={96} h={62} color={flags === 'ottoman' ? '#b3202a' : '#5a2f8e'}
          emblem={flags === 'ottoman' ? 'crescent' : 'cross'} pole={180} seed={i * 2} slack={flagSlack} />
      ))}
    </g>
  );
};

export const Tents: React.FC<{x: number; y: number; s?: number; n?: number; seed?: number; gap?: number}> = ({x, y, s = 1, n = 4, seed = 3, gap = 300}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    {Array.from({length: n}).map((_, i) => {
      const w = 190 + random(`t${seed}${i}`) * 60;
      const h = 150 + random(`th${seed}${i}`) * 50;
      const cx = i * gap;
      return (
        <g key={i} transform={`translate(${cx} 0)`}>
          <ellipse cx={0} cy={4} rx={w * 0.6} ry={12} fill="#000" opacity={0.18} />
          <path d={`M${-w / 2} 0 L${-w / 2} ${-h * 0.55} Q0 ${-h * 1.35} ${w / 2} ${-h * 0.55} L${w / 2} 0 Z`} fill="url(#stripeR)" stroke={INK} strokeWidth={4} />
          <path d={`M-30 0 Q0 ${-h * 0.5} 30 0 Z`} fill="#3a2a22" stroke={INK} strokeWidth={3} />
          <line x1={0} y1={-h * 1.05} x2={0} y2={-h * 1.3} stroke={INK} strokeWidth={4} />
          <circle cx={0} cy={-h * 1.32} r={9} fill={GOLD} stroke={INK} strokeWidth={3} />
        </g>
      );
    })}
  </g>
);

export const Ground: React.FC<{y: number; color: string; accent?: string; x0?: number; x1?: number}> = ({y, color, accent = '#8d9b4a', x0 = -1600, x1 = 3800}) => (
  <g>
    <rect x={x0} y={y} width={x1 - x0} height={1600} fill={color} />
    <rect x={x0} y={y} width={x1 - x0} height={14} fill={accent} opacity={0.55} />
    {Array.from({length: 40}).map((_, i) => {
      const gx = x0 + random(`g${i}`) * (x1 - x0), gy = y + 40 + random(`gy${i}`) * 420;
      return <path key={i} d={`M${gx} ${gy} l-8 -20 M${gx} ${gy} l0 -26 M${gx} ${gy} l8 -20`} stroke={accent} strokeWidth={5} strokeLinecap="round" />;
    })}
  </g>
);

export const Water: React.FC<{x0: number; x1: number; y0: number; y1: number; color?: string; light?: string}> = ({x0, x1, y0, y1, color = '#3f86b8', light = '#9ed0ec'}) => {
  const f = useCurrentFrame();
  const rows = Math.max(2, Math.floor((y1 - y0) / 46));
  return (
    <g>
      <rect x={x0} y={y0} width={x1 - x0} height={y1 - y0} fill={color} />
      {Array.from({length: rows}).map((_, r) => {
        const yy = y0 + 24 + r * 46;
        const d = Array.from({length: Math.ceil((x1 - x0) / 80)}).map((_, i) => {
          const px = x0 + i * 80 + ((f * (1 + r * 0.15) * 0.8 + r * 37) % 80);
          return `M${px} ${yy} q20 -12 40 0`;
        }).join(' ');
        return <path key={r} d={d} stroke={light} strokeWidth={4} fill="none" strokeLinecap="round" opacity={0.55} />;
      })}
    </g>
  );
};

export const Birds: React.FC<{n?: number; y: number; x0?: number; speed?: number}> = ({n = 5, y, x0 = -200, speed = 2.2}) => {
  const f = useCurrentFrame();
  return (
    <g stroke={INK} strokeWidth={5} fill="none" strokeLinecap="round">
      {Array.from({length: n}).map((_, i) => {
        const bx = x0 + ((random(`b${i}`) * 1600 + f * speed) % 2600);
        const by = y + (random(`by${i}`) - 0.5) * 240 + Math.sin(f * 0.05 + i) * 16;
        const fl = Math.sin(f * 0.4 + i * 2) * 14;
        return <path key={i} d={`M${bx - 24} ${by - fl} Q${bx - 10} ${by - 6} ${bx} ${by} Q${bx + 10} ${by - 6} ${bx + 24} ${by - fl}`} />;
      })}
    </g>
  );
};
