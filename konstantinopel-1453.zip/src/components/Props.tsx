import React from 'react';
import {useCurrentFrame} from 'remotion';
import {Flag} from './Flag';
import {GOLD, INK} from '../theme';

/** Huge Ottoman bombard (faces right). Barrel muzzle is at roughly (x + 290*s, y - 100*s). */
export const Cannon: React.FC<{x: number; y: number; s?: number; recoil?: number}> = ({x, y, s = 1, recoil = 0}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <ellipse cx={0} cy={6} rx={330} ry={16} fill="#000" opacity={0.25} />
    <path d="M-300 0 L300 0 L250 -66 L-250 -66 Z" fill="url(#plank)" stroke={INK} strokeWidth={6} strokeLinejoin="round" />
    <path d="M-330 0 L-250 -66 M330 0 L250 -66" stroke={INK} strokeWidth={6} />
    <g transform={`translate(${recoil} 0) rotate(-3 0 -110)`}>
      <rect x={-260} y={-160} width={530} height={104} rx={44} fill="url(#bronze)" stroke={INK} strokeWidth={6} />
      {[-170, -60, 60, 170].map((rx) => (<rect key={rx} x={rx} y={-164} width={20} height={112} rx={6} fill="#8f5a24" stroke={INK} strokeWidth={4} />))}
      <rect x={250} y={-176} width={44} height={136} rx={14} fill="#8f5a24" stroke={INK} strokeWidth={6} />
      <ellipse cx={294} cy={-108} rx={13} ry={52} fill="#17120f" />
      <circle cx={-236} cy={-158} r={8} fill={INK} />
      <path d="M-220 -150 Q-80 -176 100 -152" stroke="#f3cf8a" strokeWidth={6} fill="none" opacity={0.6} strokeLinecap="round" />
    </g>
    <rect x={-120} y={-76} width={34} height={76} fill="#6e421a" stroke={INK} strokeWidth={5} />
    <rect x={90} y={-76} width={34} height={76} fill="#6e421a" stroke={INK} strokeWidth={5} />
  </g>
);

export const Cannonball: React.FC<{x: number; y: number; r?: number}> = ({x, y, r = 28}) => (
  <g>
    <circle cx={x} cy={y} r={r} fill="#2b2b30" stroke={INK} strokeWidth={5} />
    <circle cx={x - r * 0.3} cy={y - r * 0.3} r={r * 0.28} fill="#8a8a95" opacity={0.7} />
  </g>
);

export const Ship: React.FC<{x: number; y: number; s?: number; flip?: boolean; rock?: number; sail?: boolean; flag?: boolean; sinkY?: number}> = ({
  x, y, s = 1, flip = false, rock = 0, sail = true, flag = true, sinkY = 0,
}) => {
  const f = useCurrentFrame();
  const sw = Math.sin(f * 0.25);
  return (
    <g transform={`translate(${x} ${y + sinkY}) scale(${flip ? -s : s} ${s}) rotate(${rock})`}>
      <g stroke={INK} strokeWidth={5} strokeLinecap="round">
        {[-120, -60, 0, 60, 120].map((ox, i) => (<line key={i} x1={ox} y1={-24} x2={ox + 40 + Math.sin(f * 0.25 + i) * 18} y2={30 + Math.cos(f * 0.25 + i) * 8} />))}
      </g>
      <path d="M-220 -64 Q-160 40 0 44 Q170 40 240 -90 L220 -64 L-220 -64Z" fill="#7a4a28" stroke={INK} strokeWidth={6} strokeLinejoin="round" />
      <path d="M-210 -62 L225 -62" stroke={GOLD} strokeWidth={8} />
      <path d="M-170 -34 Q0 -6 190 -40" stroke="#4a2c14" strokeWidth={5} fill="none" />
      {[-130, -60, 10, 80, 150].map((px) => (<circle key={px} cx={px} cy={-40} r={8} fill="#3a2a22" stroke={INK} strokeWidth={3} />))}
      <line x1={0} y1={-64} x2={0} y2={-330} stroke="#5b3a1c" strokeWidth={10} strokeLinecap="round" />
      {sail && (
        <path d={`M0 -320 Q${110 + sw * 8} -210 8 -110 L-8 -110 Q${-110 - sw * 8} -210 0 -320Z`} fill="#f4ead2" stroke={INK} strokeWidth={5} />
      )}
      {sail && <circle cx={0} cy={-212} r={26} fill="#b3202a" />}
      {flag && <Flag x={0} y={-350} w={96} h={60} color="#b3202a" emblem="crescent" seed={x} />}
    </g>
  );
};

export const Crate: React.FC<{x: number; y: number; s?: number}> = ({x, y, s = 1}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <rect x={-50} y={-90} width={100} height={90} fill="url(#plank)" stroke={INK} strokeWidth={5} />
    <path d="M-50 -90 L50 0 M50 -90 L-50 0" stroke="#5e3a1c" strokeWidth={5} />
  </g>
);

export const Barrel: React.FC<{x: number; y: number; s?: number}> = ({x, y, s = 1}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <path d="M-40 0 Q-52 -50 -40 -100 L40 -100 Q52 -50 40 0Z" fill="#9a6a3c" stroke={INK} strokeWidth={5} />
    <path d="M-46 -26H46M-46 -76H46" stroke="#444a52" strokeWidth={8} />
  </g>
);

export const Ladder: React.FC<{x: number; y: number; h: number; tilt?: number}> = ({x, y, h, tilt = 10}) => (
  <g transform={`translate(${x} ${y}) rotate(${tilt})`} stroke="#6b4423" strokeLinecap="round">
    <line x1={-22} y1={0} x2={-22} y2={-h} strokeWidth={8} /><line x1={22} y1={0} x2={22} y2={-h} strokeWidth={8} />
    {Array.from({length: Math.floor(h / 46)}).map((_, i) => (<line key={i} x1={-22} y1={-i * 46 - 20} x2={22} y2={-i * 46 - 20} strokeWidth={6} />))}
  </g>
);

export const Brazier: React.FC<{x: number; y: number}> = ({x, y}) => (
  <g>
    <path d={`M${x - 26} ${y} L${x - 36} ${y - 40} L${x + 36} ${y - 40} L${x + 26} ${y}Z`} fill="#3a3a40" stroke={INK} strokeWidth={4} />
  </g>
);
