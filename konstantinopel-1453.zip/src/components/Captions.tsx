import React from 'react';
import {AbsoluteFill, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import timing from '../timing.json';

interface Word {w: string; s: number; e: number}

// Word timings are estimated from character count inside each sentence window
// (sentence windows come from real pauses detected in narration mp3 - see timing.json).
const WORDS: Word[] = timing.narration.flatMap((seg) => {
  const ws = seg.t.split(' ');
  const total = ws.reduce((a, w) => a + w.length + 1.5, 0);
  let cur = seg.s;
  return ws.map((w) => {
    const d = ((w.length + 1.5) / total) * (seg.e - seg.s);
    const out = {w, s: cur, e: cur + d};
    cur += d;
    return out;
  });
});

export const Captions: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = f / fps;
  const idx = WORDS.findIndex((x) => t >= x.s && t < x.e + 0.04);
  if (idx < 0) return null;
  const cur = WORDS[idx];
  const sp = spring({frame: f - Math.round(cur.s * fps), fps, config: {damping: 12, stiffness: 220}});
  return (
    <AbsoluteFill style={{top: 1300, height: 260, alignItems: 'center', justifyContent: 'center', pointerEvents: 'none'}}>
      <div style={{
        fontFamily: '"Arial Black","Helvetica Neue","DejaVu Sans",Arial,sans-serif', fontWeight: 900, fontSize: 104, color: '#fff',
        WebkitTextStroke: '14px #000', paintOrder: 'stroke fill', textAlign: 'center', padding: '0 40px', whiteSpace: 'nowrap',
        transform: `scale(${0.82 + 0.18 * sp})`, textShadow: '0 6px 0 rgba(0,0,0,0.35)', letterSpacing: -1,
      }}>{cur.w.replace(/[.,]$/, '')}</div>
    </AbsoluteFill>
  );
};
