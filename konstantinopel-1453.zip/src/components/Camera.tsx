import React, {createContext, useContext} from 'react';
import {AbsoluteFill, Easing, interpolate, random, useCurrentFrame} from 'remotion';
import {H, W} from '../theme';

export interface CamKey {f: number; x: number; y: number; z: number; r?: number}
export interface Shake {at: number; dur: number; amp: number}

const CamCtx = createContext({x: W / 2, y: H / 2, z: 1});
export const useCamera = () => useContext(CamCtx);

/** Shared SVG patterns / gradients used by all scenes. */
export const SharedDefs: React.FC = () => (
  <defs>
    <pattern id="brick" width="84" height="50" patternUnits="userSpaceOnUse">
      <rect width="84" height="50" fill="#dccaa5" />
      <path d="M0 0H84M0 25H84M0 50H84M42 0V25M0 25V50M84 25V50" stroke="#a9926b" strokeWidth="3" fill="none" />
      <path d="M6 8h14M50 33h18M20 36h10" stroke="#c4af88" strokeWidth="4" />
    </pattern>
    <pattern id="plank" width="60" height="60" patternUnits="userSpaceOnUse">
      <rect width="60" height="60" fill="#9a6a3c" />
      <path d="M0 0H60M0 30H60" stroke="#5e3a1c" strokeWidth="3" />
      <path d="M8 12h22M32 44h20" stroke="#b58552" strokeWidth="3" />
    </pattern>
    <pattern id="stripeR" width="44" height="44" patternUnits="userSpaceOnUse" patternTransform="rotate(0)">
      <rect width="44" height="44" fill="#f2e6c9" />
      <rect width="22" height="44" fill="#b9302a" />
    </pattern>
    <linearGradient id="shadeL" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0" stopColor="#ffffff" stopOpacity="0.18" />
      <stop offset="0.55" stopColor="#000" stopOpacity="0" />
      <stop offset="1" stopColor="#2a1a30" stopOpacity="0.35" />
    </linearGradient>
    <linearGradient id="bronze" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stopColor="#e3a85b" />
      <stop offset="0.5" stopColor="#b9772f" />
      <stop offset="1" stopColor="#6e421a" />
    </linearGradient>
    <radialGradient id="headG" cx="0.38" cy="0.32" r="0.8">
      <stop offset="0" stopColor="#ffffff" />
      <stop offset="0.7" stopColor="#f6f1e8" />
      <stop offset="1" stopColor="#d9d2c6" />
    </radialGradient>
    <radialGradient id="sunG" cx="0.5" cy="0.5" r="0.5">
      <stop offset="0" stopColor="#fffbe0" />
      <stop offset="0.6" stopColor="#ffe9a8" />
      <stop offset="1" stopColor="#ffd37a" stopOpacity="0" />
    </radialGradient>
    <filter id="blur8" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="8" /></filter>
    <filter id="blur3" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="3" /></filter>
  </defs>
);

export const Camera: React.FC<{keys: CamKey[]; shakes?: Shake[]; children: React.ReactNode}> = ({keys, shakes = [], children}) => {
  const f = useCurrentFrame();
  const fs = keys.map((k) => k.f);
  const ip = (v: (k: CamKey) => number) =>
    interpolate(f, fs, keys.map(v), {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.inOut(Easing.cubic)});
  const x = ip((k) => k.x), y = ip((k) => k.y), z = ip((k) => k.z), r = ip((k) => k.r ?? 0);
  let sx = 0, sy = 0;
  for (const s of shakes) {
    if (f >= s.at && f < s.at + s.dur) {
      const t = (f - s.at) / s.dur;
      const d = (1 - t) * (1 - t);
      sx += (random(`sx${f}${s.at}`) - 0.5) * 2 * s.amp * d;
      sy += (random(`sy${f}${s.at}`) - 0.5) * 2 * s.amp * d;
    }
  }
  return (
    <AbsoluteFill>
      <svg viewBox={`0 0 ${W} ${H}`} width={W} height={H} style={{display: 'block'}}>
        <SharedDefs />
        <CamCtx.Provider value={{x, y, z}}>
          <g transform={`translate(${W / 2 + sx} ${H / 2 + sy}) rotate(${r}) scale(${z}) translate(${-x} ${-y})`}>{children}</g>
        </CamCtx.Provider>
      </svg>
    </AbsoluteFill>
  );
};

/** depth 1 = moves with the world, <1 = far away (moves less), >1 = foreground. */
export const Parallax: React.FC<{depth: number; children: React.ReactNode}> = ({depth, children}) => {
  const c = useCamera();
  return <g transform={`translate(${(c.x - W / 2) * (1 - depth)} ${(c.y - H / 2) * (1 - depth)})`}>{children}</g>;
};
