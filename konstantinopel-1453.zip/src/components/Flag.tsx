import React from 'react';
import {useCurrentFrame} from 'remotion';
import {GOLD, INK} from '../theme';

export type Emblem = 'crescent' | 'cross' | 'none';

export const Flag: React.FC<{
  x: number; y: number; w: number; h: number; color: string; emblem?: Emblem;
  speed?: number; pole?: number; seed?: number; slack?: number;
}> = ({x, y, w, h, color, emblem = 'none', speed = 1, pole = 0, seed = 0, slack = 1}) => {
  const f = useCurrentFrame();
  const n = 10;
  const top: string[] = [];
  const bot: string[] = [];
  for (let i = 0; i <= n; i++) {
    const u = i / n;
    const dy = Math.sin(f * 0.2 * speed - i * 0.75 + seed) * (u * h * 0.13) * slack;
    const droop = (1 - slack) * u * h * 0.9;
    top.push(`${x + w * u * (1 - 0.1 * (1 - slack))} ${y + dy + droop}`);
    bot.push(`${x + w * u * (1 - 0.1 * (1 - slack))} ${y + h + dy + droop * 1.1}`);
  }
  const midI = 4;
  const my = y + h / 2 + Math.sin(f * 0.2 * speed - midI * 0.75 + seed) * ((midI / n) * h * 0.13) * slack + (1 - slack) * (midI / n) * h * 0.95;
  const mx = x + w * 0.45;
  const path = `M${top.join(' L')} L${bot.reverse().join(' L')} Z`;
  return (
    <g>
      {pole > 0 && <line x1={x} y1={y - 10} x2={x} y2={y + pole} stroke="#5b3a1c" strokeWidth={9} strokeLinecap="round" />}
      {pole > 0 && <circle cx={x} cy={y - 12} r={9} fill={GOLD} stroke={INK} strokeWidth={3} />}
      <path d={path} fill={color} stroke={INK} strokeWidth={4} strokeLinejoin="round" />
      {emblem === 'crescent' && (
        <g>
          <circle cx={mx} cy={my} r={h * 0.24} fill="#f7f2e4" />
          <circle cx={mx + h * 0.08} cy={my} r={h * 0.2} fill={color} />
          <circle cx={mx + h * 0.2} cy={my} r={h * 0.05} fill="#f7f2e4" />
        </g>
      )}
      {emblem === 'cross' && (
        <g fill={GOLD} stroke={INK} strokeWidth={2}>
          <rect x={mx - h * 0.05} y={my - h * 0.28} width={h * 0.1} height={h * 0.56} />
          <rect x={mx - h * 0.28} y={my - h * 0.05} width={h * 0.56} height={h * 0.1} />
        </g>
      )}
    </g>
  );
};
