import React from 'react';
import {useCurrentFrame} from 'remotion';
import {Flag} from './Flag';
import {GOLD, INK} from '../theme';

export type Costume = 'mehmed' | 'constantine' | 'ottoman' | 'byzantine';
export type Mood = 'smug' | 'serious' | 'shout' | 'worry' | 'determined' | 'awe' | 'happy';
export type Pose = 'idle' | 'point' | 'raise' | 'run' | 'march' | 'stab' | 'cheer' | 'haul' | 'hip';
export type Item = 'none' | 'spear' | 'sword' | 'shield-spear' | 'flag' | 'torch' | 'rope';

export interface CharacterProps {
  costume: Costume; x: number; y: number; scale?: number; flip?: boolean;
  mood?: Mood; pose?: Pose; item?: Item; speed?: number; offset?: number;
  flagColor?: string; talk?: boolean; look?: number; variant?: number;
}

const PAL: Record<Costume, {robe: string; trim: string; belt: string; shield: string}> = {
  mehmed: {robe: '#b3202a', trim: GOLD, belt: GOLD, shield: '#b3202a'},
  constantine: {robe: '#6a2c91', trim: GOLD, belt: GOLD, shield: '#6a2c91'},
  ottoman: {robe: '#c4502f', trim: '#f0d9a0', belt: '#3b2a1a', shield: '#a8321f'},
  byzantine: {robe: '#4a3a9a', trim: GOLD, belt: '#3b2a1a', shield: '#5a2f8e'},
};
const STEEL = '#aab4bf';
const STEEL_D = '#6f7b88';

const BROWS: Record<Mood, [number, number, number, number]> = {
  smug: [-32, -20, -26, -38], serious: [-34, -22, -22, -34], shout: [-38, -26, -26, -38],
  worry: [-22, -36, -36, -22], determined: [-36, -22, -22, -36], awe: [-40, -40, -40, -40], happy: [-34, -32, -32, -34],
};

const limb = (sx: number, sy: number, a: number, dir: number, L: number, bend: number) => {
  const ex = sx + dir * Math.sin(a) * L;
  const ey = sy + Math.cos(a) * L;
  const dx = ex - sx, dy = ey - sy;
  const len = Math.hypot(dx, dy) || 1;
  const cx = (sx + ex) / 2 + (-dy / len) * bend;
  const cy = (sy + ey) / 2 + (dx / len) * bend;
  return {d: `M${sx} ${sy} Q${cx} ${cy} ${ex} ${ey}`, ex, ey};
};

export const Flame: React.FC<{x: number; y: number; s?: number}> = ({x, y, s = 1}) => {
  const f = useCurrentFrame();
  const k = 1 + 0.12 * Math.sin(f * 0.7 + x) + 0.06 * Math.sin(f * 1.3);
  return (
    <g transform={`translate(${x} ${y}) scale(${s} ${s * k})`}>
      <path d="M0 0 C-26 -10 -22 -46 0 -78 C22 -46 26 -10 0 0Z" fill="#f07a1a" stroke={INK} strokeWidth={3} />
      <path d="M0 -4 C-14 -10 -12 -32 0 -52 C12 -32 14 -10 0 -4Z" fill="#ffd65a" />
    </g>
  );
};

const Hat: React.FC<{costume: Costume; variant: number}> = ({costume, variant}) => {
  if (costume === 'mehmed') {
    return (
      <g stroke={INK} strokeWidth={5} strokeLinejoin="round">
        <ellipse cx={0} cy={-46} rx={68} ry={30} fill="#f4eede" />
        <ellipse cx={0} cy={-76} rx={46} ry={38} fill="#fbf7ec" />
        <path d="M-58 -50 Q0 -88 58 -50 M-48 -66 Q0 -102 48 -66 M-38 -82 Q0 -108 38 -82" fill="none" stroke="#b9ae92" strokeWidth={4} />
        <circle cx={18} cy={-58} r={11} fill={GOLD} />
        <circle cx={18} cy={-58} r={4.5} fill="#b3202a" stroke="none" />
        <path d="M22 -66 Q48 -112 40 -128 Q30 -100 20 -70Z" fill="#c42a33" />
      </g>
    );
  }
  if (costume === 'constantine') {
    return (
      <g stroke={INK} strokeWidth={5} strokeLinejoin="round">
        <path d="M-50 -46 L-56 -96 L-28 -72 L0 -108 L28 -72 L56 -96 L50 -46 Z" fill={GOLD} />
        <rect x={-52} y={-56} width={104} height={14} rx={5} fill="#f0ca55" />
        <circle cx={0} cy={-84} r={7} fill="#b3202a" />
        <circle cx={-28} cy={-62} r={5} fill="#3b6fd0" />
        <circle cx={28} cy={-62} r={5} fill="#3b6fd0" />
        <circle cx={-56} cy={-30} r={6} fill="#f6f1e8" /><circle cx={-58} cy={-12} r={6} fill="#f6f1e8" />
        <circle cx={56} cy={-30} r={6} fill="#f6f1e8" /><circle cx={58} cy={-12} r={6} fill="#f6f1e8" />
      </g>
    );
  }
  if (costume === 'ottoman') {
    return (
      <g stroke={INK} strokeWidth={5} strokeLinejoin="round">
        <path d="M-56 -40 Q0 -128 56 -40 Z" fill={STEEL} />
        <path d="M0 -84 L0 -112" stroke={STEEL_D} strokeWidth={7} />
        <path d="M-60 -38 Q0 -62 60 -38 L56 -22 Q0 -44 -56 -22Z" fill={variant ? '#2f7f7a' : '#f4eede'} />
      </g>
    );
  }
  return (
    <g stroke={INK} strokeWidth={5} strokeLinejoin="round">
      <path d="M-58 -26 Q-60 -108 0 -112 Q60 -108 58 -26 Z" fill={STEEL} />
      <path d="M-8 -26 L-8 6 L8 6 L8 -26" fill={STEEL_D} />
      <path d="M-4 -110 Q40 -150 62 -96 Q36 -112 12 -104Z" fill="#b3202a" />
      <path d="M-58 -30 H58" stroke={GOLD} strokeWidth={8} />
    </g>
  );
};

export const Character: React.FC<CharacterProps> = ({
  costume, x, y, scale = 1, flip = false, mood = 'serious', pose = 'idle', item = 'none',
  speed = 1, offset = 0, flagColor, talk = false, look = 0, variant = 0,
}) => {
  const f = useCurrentFrame() + offset;
  const pal = PAL[costume];
  const robe = costume === 'ottoman' && variant ? '#2f7f7a' : pal.robe;
  const ph = f * 0.34 * speed;
  const walking = pose === 'run' || pose === 'march' || pose === 'haul';
  const amp = pose === 'run' ? 0.78 : pose === 'march' ? 0.5 : pose === 'haul' ? 0.4 : 0.05;
  const royal = costume === 'mehmed' || costume === 'constantine';

  // legs
  const legs = [0, Math.PI].map((p, i) => {
    const a = Math.sin(ph + p) * amp + (pose === 'idle' || pose === 'point' || pose === 'hip' ? (i ? 0.1 : -0.1) : 0);
    const hx = i ? 12 : -12;
    const lift = walking ? 16 * Math.max(0, Math.cos(ph + p)) : 0;
    const fx = hx + Math.sin(a) * 105;
    const fy = -105 + Math.cos(a) * 105 - lift;
    return {hx, fx, fy, kx: (hx + fx) / 2 + 9, ky: (-105 + fy) / 2};
  });

  // arms (angle from straight-down; positive = away from body)
  let Ra = 0.3 + 0.04 * Math.sin(f * 0.07), La = 0.3 + 0.04 * Math.sin(f * 0.07 + 1);
  let Rb = 6, Lb = -6;
  if (pose === 'hip') { Ra = 0.45; La = 0.7; Lb = -40; }
  if (pose === 'point') { Ra = 1.75 + 0.06 * Math.sin(f * 0.2); La = 0.7; Lb = -40; Rb = 2; }
  if (pose === 'raise') { Ra = 2.7 + 0.1 * Math.sin(f * 0.25); La = 2.5 + 0.1 * Math.sin(f * 0.25 + 1); }
  if (pose === 'cheer') { Ra = 2.6 + 0.35 * Math.sin(f * 0.45); La = 2.6 + 0.35 * Math.sin(f * 0.45 + 3); }
  if (pose === 'run') { Ra = 0.5 + 0.85 * Math.sin(ph + Math.PI); La = 0.4 + 0.85 * Math.sin(ph); }
  if (pose === 'march') { Ra = 0.35 + 0.4 * Math.sin(ph + Math.PI); La = 0.35 + 0.4 * Math.sin(ph); }
  if (pose === 'haul') { Ra = 1.25; La = 1.05; Rb = 14; }
  if (pose === 'stab') { Ra = 1.0 + 0.5 * Math.sin(f * 0.5); La = 0.8; }
  if (item === 'spear' || item === 'shield-spear' || item === 'sword') { if (pose !== 'stab' && pose !== 'run') Ra = 0.7; }
  if (item === 'flag' || item === 'torch') { if (pose === 'idle' || pose === 'march') Ra = 0.9; }
  if (item === 'shield-spear') La = 0.9;

  const lean = pose === 'haul' ? 13 : pose === 'run' ? 8 : 0;
  const sy = -184;
  const rArm = limb(36, sy, Ra, 1, 92, Rb);
  const lArm = limb(-36, sy, La, -1, 92, Lb);
  const bob = walking ? 5 * Math.abs(Math.sin(ph)) : 2 * Math.sin(f * 0.08);
  const blink = (f + 31) % 96 < 4;
  const [bLo, bLi, bRi, bRo] = BROWS[mood];
  const lidded = mood === 'smug' || mood === 'determined';
  const eyeRy = blink ? 1.5 : lidded ? 6 : mood === 'awe' || mood === 'shout' ? 12 : 9.5;
  const mo = talk || mood === 'shout' ? 0.55 + 0.45 * Math.abs(Math.sin(f * 0.45)) : 1;
  const sway = Math.sin(f * 0.06) * 1.2;

  const s = flip ? -scale : scale;
  const fc = flagColor ?? (costume === 'byzantine' || costume === 'constantine' ? '#5a2f8e' : '#b3202a');
  const emblem = costume === 'byzantine' || costume === 'constantine' ? 'cross' : 'crescent';

  return (
    <g transform={`translate(${x} ${y}) scale(${s} ${scale})`}>
      <ellipse cx={0} cy={4} rx={78} ry={13} fill="#000" opacity={0.22} />
      <g stroke={INK} strokeWidth={10} strokeLinecap="round" fill="none">
        {legs.map((l, i) => (<path key={i} d={`M${l.hx} -105 Q${l.kx} ${l.ky} ${l.fx} ${l.fy}`} />))}
      </g>
      {legs.map((l, i) => (<ellipse key={i} cx={l.fx + 13} cy={l.fy + 6} rx={26} ry={12} fill={INK} />))}

      <g transform={`rotate(${lean + sway} 0 -105)`}>
        {/* back arm */}
        <path d={lArm.d} stroke={INK} strokeWidth={10} strokeLinecap="round" fill="none" />
        <circle cx={lArm.ex} cy={lArm.ey} r={14} fill={INK} />
        {item === 'shield-spear' && (
          <g transform={`translate(${lArm.ex - 8} ${lArm.ey - 6})`} stroke={INK} strokeWidth={5}>
            <circle r={56} fill={pal.shield} />
            <circle r={42} fill="none" stroke={costume === 'byzantine' ? GOLD : '#f0d9a0'} strokeWidth={5} />
            <circle r={14} fill={STEEL} />
            {costume === 'byzantine' && <path d="M0 -36V36M-36 0H36" stroke={GOLD} strokeWidth={6} />}
          </g>
        )}

        {/* robe skirt for royals */}
        {royal && <path d="M-40 -112 L-52 -70 Q0 -56 52 -70 L40 -112 Z" fill={robe} stroke={INK} strokeWidth={5} strokeLinejoin="round" />}
        {royal && <path d="M-52 -70 Q0 -56 52 -70" fill="none" stroke={pal.trim} strokeWidth={7} />}
        {/* torso */}
        <rect x={-40} y={-206} width={80} height={102} rx={20} fill={robe} stroke={INK} strokeWidth={5} />
        <rect x={-40} y={-206} width={80} height={102} rx={20} fill="url(#shadeL)" />
        {royal && <rect x={-9} y={-206} width={18} height={102} fill={pal.trim} stroke={INK} strokeWidth={3} />}
        {royal && <path d="M-40 -190 Q0 -170 40 -190" fill="none" stroke={pal.trim} strokeWidth={6} />}
        {costume === 'byzantine' && (<g><path d="M-34 -196 Q0 -170 34 -196 L30 -140 Q0 -126 -30 -140Z" fill={STEEL} stroke={INK} strokeWidth={4} /><circle cx={-14} cy={-170} r={3} fill={STEEL_D} /><circle cx={14} cy={-170} r={3} fill={STEEL_D} /></g>)}
        {costume === 'ottoman' && <path d="M-40 -200 L40 -128" stroke="#f0d9a0" strokeWidth={9} />}
        <rect x={-41} y={-142} width={82} height={16} fill={pal.belt} stroke={INK} strokeWidth={4} />
        <rect x={-8} y={-146} width={16} height={24} rx={3} fill={GOLD} stroke={INK} strokeWidth={3} />
        <ellipse cx={0} cy={-206} rx={32} ry={9} fill={INK} />

        {/* head */}
        <g transform={`translate(${look * 6} ${-266 - bob})`}>
          <circle r={64} fill="url(#headG)" stroke={INK} strokeWidth={6} />
          <g stroke={INK} strokeWidth={9} strokeLinecap="round">
            <line x1={-40} y1={bLo} x2={-10} y2={bLi} />
            <line x1={10} y1={bRi} x2={40} y2={bRo} />
          </g>
          <g fill={INK}>
            <ellipse cx={-22 + look * 3} cy={-4} rx={8} ry={eyeRy} />
            <ellipse cx={22 + look * 3} cy={-4} rx={8} ry={eyeRy} />
          </g>
          {!blink && <g fill="#fff"><circle cx={-24 + look * 3} cy={-8} r={2.6} /><circle cx={20 + look * 3} cy={-8} r={2.6} /></g>}
          {lidded && <g stroke={INK} strokeWidth={6} strokeLinecap="round"><line x1={-33} y1={-9} x2={-9} y2={-9} /><line x1={9} y1={-9} x2={33} y2={-9} /></g>}
          {(mood === 'smug' || mood === 'happy') && (
            <g>
              <path d={`M-24 22 Q0 ${22 + 36 * mo} 24 22 Z`} fill="#8e1f2a" stroke={INK} strokeWidth={5} strokeLinejoin="round" />
              <ellipse cx={0} cy={22 + 24 * mo} rx={11} ry={7 * mo + 1} fill="#e8707b" />
            </g>
          )}
          {mood === 'serious' && <path d="M-16 30 Q0 27 16 30" fill="none" stroke={INK} strokeWidth={5} strokeLinecap="round" />}
          {mood === 'determined' && <path d="M-18 32 Q0 24 18 32" fill="none" stroke={INK} strokeWidth={5.5} strokeLinecap="round" />}
          {mood === 'worry' && <path d={`M-16 34 Q-8 26 0 33 Q8 26 16 34`} fill="none" stroke={INK} strokeWidth={5} strokeLinecap="round" />}
          {mood === 'shout' && <ellipse cx={0} cy={28} rx={17} ry={20 * mo} fill="#6f1a24" stroke={INK} strokeWidth={5} />}
          {mood === 'awe' && <ellipse cx={0} cy={30} rx={9} ry={11} fill="#6f1a24" stroke={INK} strokeWidth={4} />}
          <Hat costume={costume} variant={variant} />
        </g>

        {/* front arm + hand + items */}
        <path d={rArm.d} stroke={INK} strokeWidth={10} strokeLinecap="round" fill="none" />
        <circle cx={rArm.ex} cy={rArm.ey} r={15} fill={INK} />
        {pose === 'point' && <path d={`M${rArm.ex} ${rArm.ey} l28 -6`} stroke={INK} strokeWidth={11} strokeLinecap="round" />}
        {(item === 'spear' || item === 'shield-spear') && (
          <g transform={`translate(${rArm.ex} ${rArm.ey}) rotate(${pose === 'stab' || pose === 'run' ? 62 : 6})`}>
            <line x1={0} y1={110} x2={0} y2={-280} stroke="#6b4423" strokeWidth={8} strokeLinecap="round" />
            <polygon points="0,-318 -11,-278 11,-278" fill={STEEL} stroke={INK} strokeWidth={4} />
          </g>
        )}
        {item === 'sword' && (
          <g transform={`translate(${rArm.ex} ${rArm.ey}) rotate(${pose === 'stab' ? 50 : 24})`}>
            <line x1={0} y1={8} x2={0} y2={-124} stroke={STEEL} strokeWidth={11} strokeLinecap="round" />
            <line x1={0} y1={8} x2={0} y2={-124} stroke={INK} strokeWidth={3} />
            <line x1={-16} y1={4} x2={16} y2={4} stroke={GOLD} strokeWidth={8} strokeLinecap="round" />
          </g>
        )}
        {item === 'torch' && (
          <g transform={`translate(${rArm.ex} ${rArm.ey})`}>
            <line x1={0} y1={30} x2={0} y2={-70} stroke="#5b3a1c" strokeWidth={9} strokeLinecap="round" />
            <Flame x={0} y={-62} s={1.1} />
          </g>
        )}
        {item === 'flag' && (
          <g transform={`translate(${rArm.ex} ${rArm.ey})`}>
            <line x1={0} y1={70} x2={0} y2={-330} stroke="#5b3a1c" strokeWidth={8} strokeLinecap="round" />
            <Flag x={0} y={-330} w={150} h={100} color={fc} emblem={emblem} seed={offset} />
          </g>
        )}
        {item === 'rope' && <path d={`M${rArm.ex} ${rArm.ey} Q${rArm.ex + 120} ${rArm.ey + 10} ${rArm.ex + 260} ${rArm.ey - 30}`} stroke="#7a5a32" strokeWidth={7} fill="none" />}
      </g>
    </g>
  );
};
