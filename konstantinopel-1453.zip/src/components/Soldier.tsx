import React from 'react';
import {useCurrentFrame, random} from 'remotion';
import {INK} from '../theme';

/** Lightweight crowd soldier (same visual language: round white head, thick outline, black limbs). */
export const MiniSoldier: React.FC<{
  x: number; y: number; s?: number; robe?: string; hat?: 'turban' | 'helmet' | 'byz'; phase?: number;
  march?: boolean; spear?: boolean; flip?: boolean;
}> = ({x, y, s = 1, robe = '#c4502f', hat = 'turban', phase = 0, march = false, spear = true, flip = false}) => {
  const f = useCurrentFrame();
  const p = f * 0.3 + phase;
  const a = march ? Math.sin(p) * 0.55 : 0.04;
  const bob = march ? Math.abs(Math.sin(p)) * 4 : Math.sin(f * 0.07 + phase) * 1.5;
  return (
    <g transform={`translate(${x} ${y}) scale(${flip ? -s : s} ${s})`}>
      <ellipse cx={0} cy={2} rx={26} ry={5} fill="#000" opacity={0.2} />
      <g stroke={INK} strokeWidth={5} strokeLinecap="round">
        <line x1={-5} y1={-38} x2={-5 + Math.sin(a) * 38} y2={-38 + Math.cos(a) * 38 - (march ? 5 * Math.max(0, Math.cos(p)) : 0)} />
        <line x1={5} y1={-38} x2={5 - Math.sin(a) * 38} y2={-38 + Math.cos(a) * 38 - (march ? 5 * Math.max(0, -Math.cos(p)) : 0)} />
      </g>
      {spear && <line x1={16} y1={0} x2={16} y2={-150} stroke="#6b4423" strokeWidth={4} />}
      {spear && <polygon points="16,-166 11,-148 21,-148" fill="#aab4bf" stroke={INK} strokeWidth={2} />}
      <rect x={-16} y={-84 - bob} width={32} height={48} rx={9} fill={robe} stroke={INK} strokeWidth={3} />
      <circle cx={0} cy={-104 - bob} r={22} fill="#fbf8f1" stroke={INK} strokeWidth={3.5} />
      <ellipse cx={-7} cy={-104 - bob} rx={2.6} ry={3.4} fill={INK} />
      <ellipse cx={7} cy={-104 - bob} rx={2.6} ry={3.4} fill={INK} />
      <path d={`M-6 -94 Q0 -90 6 -94`} stroke={INK} strokeWidth={2.5} fill="none" />
      {hat === 'turban' && <ellipse cx={0} cy={-122 - bob} rx={24} ry={11} fill="#f4eede" stroke={INK} strokeWidth={3} />}
      {hat === 'helmet' && <path d={`M-22 ${-110 - bob} Q0 ${-146 - bob} 22 ${-110 - bob}Z`} fill="#aab4bf" stroke={INK} strokeWidth={3} />}
      {hat === 'byz' && <g><path d={`M-22 ${-108 - bob} Q0 ${-146 - bob} 22 ${-108 - bob}Z`} fill="#aab4bf" stroke={INK} strokeWidth={3} /><path d={`M0 ${-136 - bob} q14 -14 22 6`} fill="#b3202a" stroke={INK} strokeWidth={2} /></g>}
    </g>
  );
};

/** Rows of soldiers receding into the distance (perspective scaling). */
export const Army: React.FC<{
  x0: number; x1: number; yFar: number; yNear: number; rows: number; cols: number;
  robe?: string; seed?: number; march?: boolean; hat?: 'turban' | 'helmet' | 'byz'; flip?: boolean;
}> = ({x0, x1, yFar, yNear, rows, cols, robe = '#c4502f', seed = 1, march = false, hat = 'turban', flip = false}) => {
  const out: React.ReactNode[] = [];
  for (let r = 0; r < rows; r++) {
    const u = rows === 1 ? 1 : r / (rows - 1);
    const y = yFar + (yNear - yFar) * u;
    const s = 0.34 + 0.5 * u;
    for (let c = 0; c < cols; c++) {
      const x = x0 + ((x1 - x0) * (c + 0.5 + (random(`${seed}x${r}${c}`) - 0.5) * 0.5)) / cols;
      const alt = random(`${seed}c${r}${c}`) > 0.8;
      out.push(
        <MiniSoldier key={`${r}-${c}`} x={x} y={y + (random(`${seed}y${r}${c}`) - 0.5) * 12} s={s} phase={random(`${seed}p${r}${c}`) * 6}
          robe={alt ? '#2f7f7a' : robe} hat={hat} march={march} flip={flip} />,
      );
    }
  }
  return <g>{out}</g>;
};
