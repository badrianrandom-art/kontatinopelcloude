import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';

/** Fades its children out over [from, from+dur] (used to cross-dissolve into the next scene beneath). */
export const FadeOut: React.FC<{from: number; dur: number; children: React.ReactNode}> = ({from, dur, children}) => {
  const f = useCurrentFrame();
  const o = interpolate(f, [from, from + dur], [1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return <AbsoluteFill style={{opacity: o}}>{children}</AbsoluteFill>;
};

export const FadeIn: React.FC<{dur?: number; children: React.ReactNode}> = ({dur = 8, children}) => {
  const f = useCurrentFrame();
  return <AbsoluteFill style={{opacity: interpolate(f, [0, dur], [0, 1], {extrapolateRight: 'clamp'})}}>{children}</AbsoluteFill>;
};

/** Cinematic overlay: vignette, soft warm grade and letterbox-free film grain-ish tint. */
export const Grade: React.FC = () => (
  <AbsoluteFill style={{pointerEvents: 'none'}}>
    <AbsoluteFill style={{background: 'radial-gradient(ellipse at 50% 45%, rgba(0,0,0,0) 55%, rgba(10,6,20,0.55) 100%)'}} />
    <AbsoluteFill style={{background: 'linear-gradient(180deg, rgba(255,214,150,0.06), rgba(40,20,70,0.10))', mixBlendMode: 'soft-light'}} />
  </AbsoluteFill>
);

export const BlackFade: React.FC<{from: number; to: number}> = ({from, to}) => {
  const f = useCurrentFrame();
  return <AbsoluteFill style={{backgroundColor: '#000', opacity: interpolate(f, [from, to], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'})}} />;
};
