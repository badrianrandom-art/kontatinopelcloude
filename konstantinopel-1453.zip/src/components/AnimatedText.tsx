import React from 'react';
import {AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';

export interface TextLine {text: string; size: number; delay: number; color?: string; spacing?: number}

const FONT = '"Cinzel","Trajan Pro","Georgia","Times New Roman",serif';

/** Pop-in cinematic title lines (spring + fade). */
export const TitleBlock: React.FC<{lines: TextLine[]; top: number; outFrom?: number; outTo?: number}> = ({lines, top, outFrom, outTo}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const out = outFrom !== undefined && outTo !== undefined ? interpolate(f, [outFrom, outTo], [1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'}) : 1;
  return (
    <AbsoluteFill style={{alignItems: 'center', top, height: 700, justifyContent: 'flex-start', opacity: out}}>
      {lines.map((l, i) => {
        const sp = spring({frame: f - l.delay, fps, config: {damping: 15, stiffness: 110}});
        const op = interpolate(f - l.delay, [0, 14], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
        return (
          <div key={i} style={{
            fontFamily: FONT, fontWeight: 900, fontSize: l.size, letterSpacing: l.spacing ?? 6, color: l.color ?? '#fff7e0',
            textAlign: 'center', lineHeight: 1.08, opacity: op, transform: `scale(${0.7 + 0.3 * sp}) translateY(${(1 - sp) * 30}px)`,
            WebkitTextStroke: `${Math.max(4, l.size * 0.07)}px #17120f`, paintOrder: 'stroke fill',
            textShadow: '0 8px 24px rgba(0,0,0,0.45)',
          }}>{l.text}</div>
        );
      })}
    </AbsoluteFill>
  );
};

/** Small lower-third style tag. */
export const Tag: React.FC<{text: string; top: number; from: number; to: number}> = ({text, top, from, to}) => {
  const f = useCurrentFrame();
  const op = interpolate(f, [from, from + 12, to - 12, to], [0, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const x = interpolate(f, [from, from + 14], [-60, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <AbsoluteFill style={{top, height: 120, alignItems: 'center', opacity: op, transform: `translateX(${x}px)`}}>
      <div style={{
        fontFamily: FONT, fontWeight: 900, fontSize: 54, letterSpacing: 8, color: '#fff7e0', padding: '12px 36px',
        background: 'rgba(23,18,15,0.55)', border: '4px solid #e8b83a', borderRadius: 14,
      }}>{text}</div>
    </AbsoluteFill>
  );
};
