import React from 'react';
import {random, useCurrentFrame} from 'remotion';
import {INK} from '../theme';

/** Expanding, rising smoke / dust puffs. Frames are local to the current Sequence. */
export const Puffs: React.FC<{
  x: number; y: number; start: number; dur?: number; count?: number; spread?: number; rise?: number;
  size?: number; color?: string; opacity?: number; seed?: string; drift?: number;
}> = ({x, y, start, dur = 70, count = 14, spread = 160, rise = 140, size = 40, color = '#d9d2c4', opacity = 0.75, seed = 'p', drift = 0}) => {
  const f = useCurrentFrame();
  return (
    <g>
      {Array.from({length: count}).map((_, i) => {
        const delay = random(`${seed}d${i}`) * dur * 0.35;
        const t = (f - start - delay) / (dur * 0.8);
        if (t < 0 || t > 1) return null;
        const px = x + (random(`${seed}x${i}`) - 0.5) * spread * (0.4 + t) + drift * t;
        const py = y - rise * t * (0.6 + random(`${seed}y${i}`) * 0.6);
        const r = size * (0.5 + t * 1.4) * (0.7 + random(`${seed}r${i}`) * 0.6);
        return <circle key={i} cx={px} cy={py} r={r} fill={color} opacity={opacity * (1 - t) * Math.min(1, t * 8)} />;
      })}
    </g>
  );
};

/** Ballistic stone chunks. */
export const Debris: React.FC<{
  x: number; y: number; start: number; dur?: number; count?: number; power?: number; ground?: number;
  color?: string; seed?: string; sizeMin?: number; sizeMax?: number;
}> = ({x, y, start, dur = 60, count = 18, power = 22, ground, color = '#b8a27a', seed = 'd', sizeMin = 10, sizeMax = 28}) => {
  const f = useCurrentFrame();
  const t = f - start;
  if (t < 0 || t > dur) return null;
  return (
    <g>
      {Array.from({length: count}).map((_, i) => {
        const a = -Math.PI * (0.15 + random(`${seed}a${i}`) * 0.7);
        const v = power * (0.45 + random(`${seed}v${i}`) * 0.8);
        let px = x + Math.cos(a) * v * t * (random(`${seed}s${i}`) > 0.5 ? 1 : -1) * 0.8;
        let py = y + Math.sin(a) * v * t + 0.55 * t * t;
        if (ground !== undefined) py = Math.min(py, ground);
        const sz = sizeMin + random(`${seed}z${i}`) * (sizeMax - sizeMin);
        const rot = t * (random(`${seed}r${i}`) - 0.5) * 30;
        return (
          <polygon key={i} points={`${-sz},${sz * 0.4} ${-sz * 0.3},${-sz * 0.6} ${sz * 0.8},${-sz * 0.2} ${sz * 0.5},${sz * 0.6}`}
            transform={`translate(${px} ${py}) rotate(${rot})`} fill={color} stroke={INK} strokeWidth={3} opacity={Math.min(1, (dur - t) / 12)} />
        );
      })}
    </g>
  );
};

/** Looping embers rising (fire / battlefield). */
export const Embers: React.FC<{x0: number; x1: number; y: number; n?: number; seed?: string; height?: number}> = ({x0, x1, y, n = 26, seed = 'e', height = 520}) => {
  const f = useCurrentFrame();
  return (
    <g>
      {Array.from({length: n}).map((_, i) => {
        const cyc = 60 + random(`${seed}c${i}`) * 80;
        const t = ((f + random(`${seed}o${i}`) * cyc) % cyc) / cyc;
        const px = x0 + random(`${seed}x${i}`) * (x1 - x0) + Math.sin(f * 0.07 + i) * 22;
        return <circle key={i} cx={px} cy={y - t * height} r={3 + random(`${seed}r${i}`) * 4} fill={t > 0.6 ? '#ff9a3c' : '#ffd25a'} opacity={(1 - t) * 0.9} />;
      })}
    </g>
  );
};

/** Looping dust drifting across the screen (atmosphere). */
export const Dust: React.FC<{y0: number; y1: number; n?: number; seed?: string; color?: string; speed?: number}> = ({y0, y1, n = 22, seed = 'u', color = '#fff2cf', speed = 3}) => {
  const f = useCurrentFrame();
  return (
    <g>
      {Array.from({length: n}).map((_, i) => {
        const px = -300 + ((random(`${seed}x${i}`) * 3000 + f * speed * (0.5 + random(`${seed}s${i}`))) % 3000);
        const py = y0 + random(`${seed}y${i}`) * (y1 - y0) + Math.sin(f * 0.04 + i) * 14;
        return <circle key={i} cx={px} cy={py} r={2 + random(`${seed}r${i}`) * 3.5} fill={color} opacity={0.5} />;
      })}
    </g>
  );
};

export const Flash: React.FC<{start: number; dur?: number; color?: string; peak?: number}> = ({start, dur = 9, color = '#fff4cf', peak = 0.9}) => {
  const f = useCurrentFrame();
  const t = (f - start) / dur;
  if (t < 0 || t > 1) return null;
  return <rect x={-3000} y={-3000} width={9000} height={9000} fill={color} opacity={peak * (1 - t)} />;
};
