import React from 'react';
import {Composition} from 'remotion';
import {Konstantinopel} from './Composition';
import {FPS, H, W} from './theme';

export const Root: React.FC = () => (
  <Composition id="Konstantinopel" component={Konstantinopel} durationInFrames={1800} fps={FPS} width={W} height={H} />
);
