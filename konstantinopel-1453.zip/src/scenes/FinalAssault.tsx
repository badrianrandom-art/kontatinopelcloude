import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {Camera, Parallax} from '../components/Camera';
import {Clouds, Ground, Hills, Sky, Tower, Wall} from '../components/Background';
import {Character, Flame} from '../components/Character';
import {Army} from '../components/Soldier';
import {Brazier, Ladder} from '../components/Props';
import {Debris, Embers, Flash, Puffs} from '../components/ParticleSystem';

import {TitleBlock} from '../components/AnimatedText';
import {ease, lerpColor} from '../theme';
import timing from '../timing.json';

const START = timing.scenes.assault[0];
const BLAST = Math.round((timing.events.assaultBlast - START) * 30);

/** SCENE 5 - night turns to dawn on 29 May 1453; the final assault. */
export const FinalAssault: React.FC = () => {
  const f = useCurrentFrame();
  const k = ease(f, 0, 189, 0, 1);
  const runX = (x0: number, spd: number, cap: number) => Math.min(cap, x0 + f * spd);
  const clash = f > 100 ? 'stab' : 'run';
  return (
    <AbsoluteFill>
      <Camera
        keys={[
          {f: 0, x: 800, y: 1190, z: 1.0}, {f: 55, x: 1010, y: 1240, z: 1.12}, {f: 80, x: 1190, y: 1330, z: 1.9},
          {f: 112, x: 1440, y: 1340, z: 1.9}, {f: 150, x: 1470, y: 1330, z: 1.75}, {f: 189, x: 1150, y: 1200, z: 1.05},
        ]}
        shakes={[{at: BLAST, dur: 30, amp: 24}]}
      >
        <Sky id="sky5" top={-200} bottom={1250} stops={[[0, lerpColor('#0b1030', '#4f78b8', k)], [0.55, lerpColor('#222c5c', '#f0a070', k)], [1, lerpColor('#3a3a6a', '#ffd9a0', k)]]} />
        <Parallax depth={0.2}><Clouds y={420} n={5} seed={17} speed={0.4} scale={1.3} tint={lerpColor('#2a3566', '#f0b890', k)} opacity={0.9} /></Parallax>
        <Parallax depth={0.5}><Hills y={1150} amp={50} color={lerpColor('#1c2548', '#9aa6bd', k)} seed={8} /></Parallax>
        <Parallax depth={0.8}><Hills y={1260} amp={40} color={lerpColor('#1f3326', '#7c9a52', k)} seed={12} /></Parallax>
        <Ground y={1480} color={lerpColor('#2c2a3a', '#b99a62', k)} accent={lerpColor('#20331f', '#7e9140', k)} />
        <Army x0={-300} x1={800} yFar={1470} yNear={1520} rows={2} cols={12} seed={5} march />
        {/* Byzantine wall, damaged */}
        <Wall x={1560} y={1500} w={1100} h={430} breach={0.55} breachX={1900} crack={1} crackX={1760} />
        <Tower x={1480} y={1500} w={150} h={540} roof="#7d2f3a" flag={{color: '#5a2f8e', emblem: 'cross'}} />
        <Tower x={2440} y={1500} w={150} h={540} flag={{color: '#5a2f8e', emblem: 'cross'}} slack={0.6} />
        {[1700, 2120, 2300].map((bx) => (<g key={bx}><Brazier x={bx} y={1090} /><Flame x={bx} y={1050} s={1.2} /></g>))}
        {[1650, 1800, 2050, 2250].map((bx, i) => (
          <Character key={bx} costume="byzantine" x={bx} y={1075} scale={0.62} flip pose={i % 2 ? 'stab' : 'idle'} item={i % 2 ? 'spear' : 'shield-spear'} mood="shout" offset={i * 6} />
        ))}
        <Ladder x={1560} y={1500} h={420} tilt={-8} /><Ladder x={2250} y={1500} h={420} tilt={8} />
        {/* defenders in the breach */}
        <Character costume="byzantine" x={1840} y={1530} scale={1.05} flip pose="stab" item="shield-spear" mood="shout" offset={3} />
        <Character costume="byzantine" x={2000} y={1550} scale={1.05} flip pose="stab" item="spear" mood="determined" offset={11} />
        <Character costume="constantine" x={2140} y={1560} scale={1.0} flip pose="raise" mood="shout" />
        {/* Ottoman charge */}
        <Character costume="ottoman" x={runX(200, 7, 1360)} y={1550} scale={1.0} pose={clash} item="shield-spear" mood="shout" speed={1.4} offset={2} />
        <Character costume="ottoman" x={runX(60, 7, 1250)} y={1600} scale={1.05} pose={clash} item="sword" mood="shout" variant={1} speed={1.4} offset={9} />
        <Character costume="ottoman" x={runX(-120, 7.2, 1130)} y={1625} scale={1.1} pose="run" item="flag" mood="shout" speed={1.4} offset={5} />
        <Character costume="ottoman" x={runX(500, 8, 1480)} y={1560} scale={1.15} pose={clash} item="shield-spear" mood="shout" speed={1.4} offset={14} />
        <Character costume="ottoman" x={runX(-300, 7.4, 1000)} y={1660} scale={1.15} pose="run" item="spear" mood="shout" variant={1} speed={1.4} offset={20} />
        {/* fire, smoke, blast */}
        <Embers x0={400} x1={2600} y={1500} n={40} height={700} />
        <Puffs x={1900} y={1180} start={0} dur={90} count={10} spread={400} rise={400} size={70} color="#444048" opacity={0.6} seed="sa" />
        <Puffs x={1900} y={1180} start={90} dur={99} count={10} spread={400} rise={400} size={70} color="#444048" opacity={0.6} seed="sb" />
        <Flash start={BLAST} dur={8} peak={0.6} color="#ffd9a0" />
        <Debris x={1900} y={1250} start={BLAST} dur={60} count={26} power={22} ground={1500} seed="as" />
        <Puffs x={1900} y={1300} start={BLAST} dur={90} count={20} spread={420} rise={320} size={64} color="#6b6460" seed="ab" />
        <rect x={-3000} y={-3000} width={9000} height={9000} fill="#0a0e24" opacity={0.42 * (1 - k)} />
      </Camera>
      <TitleBlock top={170} lines={[{text: '29 MEI 1453', size: 92, delay: 8, color: '#ffe3a8'}]} outFrom={70} outTo={90} />
    </AbsoluteFill>
  );
};
