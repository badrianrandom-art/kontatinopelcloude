import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {Camera, Parallax} from '../components/Camera';
import {Birds, City, Clouds, Hills, Sky, Sun, Tower, Wall, Water} from '../components/Background';
import {Character} from '../components/Character';
import {Dust} from '../components/ParticleSystem';
import {Flag} from '../components/Flag';
import {Tag} from '../components/AnimatedText';
import {ease} from '../theme';

/** SCENE 1 - aerial approach to the Theodosian walls, reveal of Constantine XI. */
export const Opening: React.FC = () => {
  const f = useCurrentFrame();
  const towers = [-380, 0, 380, 760, 1140, 1520];
  const point = f > 150;
  return (
    <AbsoluteFill>
      <Camera keys={[{f: 0, x: 540, y: 620, z: 1.0}, {f: 110, x: 560, y: 930, z: 1.2}, {f: 240, x: 650, y: 1175, z: 1.95}]}>
        <Sky id="sky1" top={-200} bottom={1150} stops={[[0, '#4f7fc8'], [0.55, '#e9b48f'], [1, '#ffd9a0']]} />
        <Parallax depth={0.1}><Sun x={330} y={900} r={105} /></Parallax>
        <Parallax depth={0.2}><Clouds y={380} n={5} seed={2} speed={0.5} scale={1.2} /><Clouds y={760} n={4} seed={7} speed={0.8} scale={0.8} tint="#f3c9a5" opacity={0.9} /></Parallax>
        <Parallax depth={0.3}><Birds y={560} n={6} /></Parallax>
        <Parallax depth={0.4}><Hills y={1060} amp={50} color="#a9b4c8" seed={3} /></Parallax>
        <Parallax depth={0.55}><City x={540} y={1110} s={1.35} haze={0.35} hazeColor="#f3c9a5" topper="cross" flags="byz" /></Parallax>
        <Parallax depth={0.8}>
          <Wall x={-700} y={1330} w={2600} h={240} />
        </Parallax>
        <Parallax depth={0.92}>
          <rect x={-1600} y={1500} width={5200} height={900} fill="#8fa24f" />
          <Water x0={-1600} x1={3600} y0={1500} y1={1600} color="#4a86b3" />
        </Parallax>
        {/* main wall + towers */}
        <Wall x={-700} y={1500} w={2600} h={260} />
        {towers.map((tx, i) => (
          <Tower key={tx} x={tx} y={1500} w={130} h={380} roof={i % 2 ? '#7d2f3a' : undefined} flag={{color: '#5a2f8e', emblem: 'cross'}} />
        ))}
        {/* defenders on the walls */}
        <Character costume="byzantine" x={470} y={1250} scale={0.82} flip item="spear" mood="serious" offset={5} />
        <Character costume="byzantine" x={900} y={1250} scale={0.82} flip item="shield-spear" mood="determined" offset={12} />
        <Character costume="constantine" x={690} y={1252} scale={0.95} flip mood={point ? 'determined' : 'serious'} pose={point ? 'point' : 'idle'} look={-0.6} />
        <Parallax depth={1.25}>
          <Flag x={-90} y={880} w={300} h={190} color="#5a2f8e" emblem="cross" pole={820} seed={1} />
        </Parallax>
        <Dust y0={700} y1={1500} n={26} />
      </Camera>
      <Tag text="KONSTANTINOPEL · 1453" top={170} from={25} to={190} />
    </AbsoluteFill>
  );
};
