import React from 'react';
import {AbsoluteFill, Sequence, useCurrentFrame} from 'remotion';
import {Camera, Parallax} from '../components/Camera';
import {City, Clouds, Ground, Sky, Tower, Wall} from '../components/Background';
import {Character} from '../components/Character';
import {Army} from '../components/Soldier';
import {Debris, Dust, Embers, Puffs} from '../components/ParticleSystem';
import {Flag} from '../components/Flag';
import {FadeIn} from '../components/Transitions';
import {TitleBlock} from '../components/AnimatedText';
import {ease} from '../theme';

const DAWN: [number, string][] = [[0, '#6f8fd0'], [0.5, '#f4a77a'], [1, '#ffd7a0']];

/** A: Ottoman troops pour through the broken wall. */
const Breach: React.FC = () => {
  const f = useCurrentFrame();
  const troops = Array.from({length: 9}).map((_, i) => ({x: -700 + f * 8.5 + i * 170, y: 1560 + (i % 3) * 38, flag: i % 4 === 1, v: i % 2}));
  return (
    <Camera keys={[{f: 0, x: 600, y: 1260, z: 1.25}, {f: 130, x: 980, y: 1230, z: 1.2}]} shakes={[{at: 0, dur: 30, amp: 22}]}>
      <Sky id="sky6a" top={-200} bottom={1250} stops={DAWN} />
      <Parallax depth={0.2}><Clouds y={430} n={5} seed={31} speed={0.5} scale={1.2} tint="#f0b890" /></Parallax>
      <Parallax depth={0.5}><City x={900} y={1180} s={1.1} haze={0.45} topper="cross" flags="none" /></Parallax>
      <Ground y={1480} color="#b99a62" />
      <Wall x={-200} y={1500} w={1700} h={430} breach={ease(f, 0, 50, 0.3, 0.9)} breachX={640} />
      <Tower x={-260} y={1500} w={150} h={540} flag={{color: '#5a2f8e', emblem: 'cross'}} slack={0.35} />
      <Tower x={1420} y={1500} w={150} h={540} roof="#7d2f3a" flag={{color: '#5a2f8e', emblem: 'cross'}} slack={0.35} />
      {troops.map((t, i) => (
        <Character key={i} costume="ottoman" x={t.x} y={t.y} scale={1.05} pose="run" item={t.flag ? 'flag' : i % 3 === 0 ? 'sword' : 'spear'} mood="shout" variant={t.v} speed={1.3} offset={i * 4} />
      ))}
      <Debris x={640} y={1300} start={0} dur={60} count={28} power={20} ground={1500} seed="bq" sizeMax={34} />
      <Puffs x={640} y={1420} start={0} dur={120} count={24} spread={560} rise={360} size={70} color="#b8a888" seed="bp" />
      <Embers x0={0} x1={1800} y={1500} n={30} height={600} seed="cq" />
      <Dust y0={900} y1={1600} n={26} speed={4} />
    </Camera>
  );
};

/** B: Ottoman flag climbs the tower as the Byzantine banner comes down. */
const FlagRaise: React.FC = () => {
  const f = useCurrentFrame();
  const poleTop = 520, poleBot = 1180;
  const up = ease(f, 6, 100, poleBot, poleTop);
  const down = ease(f, 6, 80, poleTop + 40, poleBot);
  return (
    <Camera keys={[{f: 0, x: 540, y: 1330, z: 1.45}, {f: 130, x: 540, y: 900, z: 1.0}]}>
      <Sky id="sky6b" top={-200} bottom={1250} stops={DAWN} />
      <Parallax depth={0.2}><Clouds y={380} n={5} seed={41} speed={0.6} scale={1.3} tint="#f0b890" /></Parallax>
      <Parallax depth={0.5}><City x={540} y={1180} s={1.2} haze={0.4} topper="cross" /></Parallax>
      <rect x={-400} y={1430} width={2000} height={900} fill="#b8a483" />
      <Tower x={330} y={1560} w={420} h={800} />
      <rect x={300} y={760} width={480} height={30} fill="#cdb98f" stroke="#17120f" strokeWidth={5} />
      <line x1={470} y1={poleTop - 20} x2={470} y2={760} stroke="#5b3a1c" strokeWidth={10} />
      <line x1={610} y1={poleTop - 20} x2={610} y2={760} stroke="#5b3a1c" strokeWidth={10} />
      <Flag x={470} y={up - 560} w={230} h={150} color="#b3202a" emblem="crescent" speed={1.2} />
      <Flag x={610} y={down - 560} w={230} h={150} color="#5a2f8e" emblem="cross" slack={0.5} />
      <Character costume="ottoman" x={380} y={770} scale={0.8} pose="cheer" mood="happy" offset={3} />
      <Character costume="ottoman" x={700} y={770} scale={0.8} pose="cheer" mood="happy" variant={1} offset={9} flip />
      <Character costume="ottoman" x={540} y={775} scale={0.9} pose="raise" mood="shout" offset={1} />
      <Embers x0={200} x1={900} y={1300} n={20} height={600} seed="fr" />
    </Camera>
  );
};

/** C: Mehmed II overlooks the city; emotional pull-back; Byzantine -> Ottoman era. */
const Overlook: React.FC = () => {
  const f = useCurrentFrame();
  const t = ease(f, 30, 90, 0, 1);
  return (
    <AbsoluteFill>
      <Camera keys={[{f: 0, x: 380, y: 1290, z: 2.3}, {f: 80, x: 540, y: 1220, z: 1.5}, {f: 160, x: 640, y: 1040, z: 1.0}]}>
        <Sky id="sky6c" top={-200} bottom={1250} stops={[[0, '#6f8fd0'], [0.5, '#f4a77a'], [1, '#ffe0a8']]} />
        <Parallax depth={0.2}><Clouds y={400} n={5} seed={51} speed={0.4} scale={1.3} tint="#f0b890" /></Parallax>
        <Parallax depth={0.55}>
          <City x={760} y={1190} s={1.25} haze={0.3} topper="cross" flags="byz" flagSlack={1 - t} />
          <g opacity={t}><City x={760} y={1190} s={1.25} haze={0.3} topper="none" flags="ottoman" /></g>
        </Parallax>
        <Parallax depth={0.85}>
          <Ground y={1500} color="#b99a62" />
          <Army x0={-200} x1={1300} yFar={1540} yNear={1600} rows={2} cols={14} seed={9} />
        </Parallax>
        <rect x={-300} y={1290} width={900} height={900} fill="#c9b58f" stroke="#17120f" strokeWidth={6} />
        <rect x={-310} y={1275} width={920} height={24} fill="#cdb98f" stroke="#17120f" strokeWidth={5} />
        <Flag x={470} y={760} w={190} h={120} color="#b3202a" emblem="crescent" pole={540} seed={4} />
        <Character costume="mehmed" x={300} y={1290} scale={1.35} mood={f < 55 ? 'serious' : 'smug'} pose="hip" look={0.8} />
        <Character costume="ottoman" x={80} y={1295} scale={1.0} item="shield-spear" mood="determined" offset={7} />
        <Dust y0={800} y1={1500} n={24} speed={3} />
      </Camera>
      <TitleBlock top={170} outFrom={140} outTo={158} lines={[
        {text: 'BIZANTIUM', size: 72, delay: 20, color: '#d9b8ff', spacing: 10},
        {text: 'ERA OTTOMAN', size: 86, delay: 95, color: '#ff9a8a', spacing: 8},
      ]} />
    </AbsoluteFill>
  );
};

export const Conquest: React.FC = () => (
  <AbsoluteFill>
    <Sequence from={0} durationInFrames={120}><Breach /></Sequence>
    <Sequence from={110} durationInFrames={130}><FadeIn><FlagRaise /></FadeIn></Sequence>
    <Sequence from={230} durationInFrames={151}><FadeIn><Overlook /></FadeIn></Sequence>
  </AbsoluteFill>
);
