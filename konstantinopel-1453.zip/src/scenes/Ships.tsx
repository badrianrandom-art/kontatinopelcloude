import React from 'react';
import {AbsoluteFill, Sequence, useCurrentFrame} from 'remotion';
import {Camera, Parallax} from '../components/Camera';
import {Clouds, Hills, Sky, Water, Ground} from '../components/Background';
import {Character} from '../components/Character';
import {Ship} from '../components/Props';
import {Debris, Dust, Puffs} from '../components/ParticleSystem';
import {FadeIn} from '../components/Transitions';
import {Tag} from '../components/AnimatedText';
import {ease, INK} from '../theme';

const bez = (t: number, p: number[][]) => {
  const u = 1 - t;
  const c = [u * u * u, 3 * u * u * t, 3 * u * t * t, t * t * t];
  return {x: c.reduce((a, k, i) => a + k * p[i][0], 0), y: c.reduce((a, k, i) => a + k * p[i][1], 0)};
};
const ROUTE = [[800, 560], [700, 470], [610, 470], [520, 650]];
const FONT = '"Cinzel","Georgia",serif';

const MapShot: React.FC = () => {
  const f = useCurrentFrame();
  const route = ease(f, 42, 88, 0, 1, (x) => x);
  const chainPulse = 1 + 0.04 * Math.sin(f * 0.3);
  const links = Array.from({length: 9}).map((_, i) => ({x: 736 + Math.sin(i) * 3, y: 750 + i * 13}));
  const pos = bez(route, ROUTE);
  return (
    <AbsoluteFill>
      <Camera keys={[{f: 0, x: 600, y: 880, z: 0.95}, {f: 94, x: 640, y: 740, z: 1.45}]}>
        <rect x={-800} y={-600} width={3200} height={3200} fill="#e8d6ac" />
        <rect x={-200} y={80} width={1500} height={1500} fill="none" stroke="#8a6a3d" strokeWidth={10} opacity={0.6} />
        {/* sea (Bosphorus / Marmara) */}
        <path d="M800 -50 C760 400 840 700 790 900 C740 1100 900 1300 700 1650 L1700 1650 L1700 -50 Z" fill="#6fa8c9" stroke={INK} strokeWidth={5} />
        {/* Golden Horn */}
        <path d="M792 800 C610 790 450 620 150 470" stroke="#6fa8c9" strokeWidth={96} strokeLinecap="round" fill="none" />
        <path d="M792 800 C610 790 450 620 150 470" stroke={INK} strokeWidth={104} strokeLinecap="round" fill="none" opacity={0.0} />
        {/* Constantinople */}
        <path d="M330 850 C480 800 650 840 790 850 L790 1090 C700 1250 560 1250 430 1150 Z" fill="#f0dcae" stroke={INK} strokeWidth={6} strokeLinejoin="round" />
        <path d="M330 850 L430 1150" stroke="#8a4a2a" strokeWidth={16} strokeLinecap="round" />
        <path d="M330 850 L430 1150" stroke="#e8d6ac" strokeWidth={4} strokeDasharray="16 14" />
        <g fill="#c9b9a0" stroke={INK} strokeWidth={4}><ellipse cx={600} cy={990} rx={52} ry={40} /><ellipse cx={520} cy={1010} rx={30} ry={24} /><ellipse cx={680} cy={950} rx={26} ry={20} /></g>
        <text x={560} y={1090} fontFamily={FONT} fontWeight={900} fontSize={40} fill="#4a2c14" textAnchor="middle" letterSpacing={4}>KONSTANTINOPEL</text>
        <text x={330} y={620} fontFamily={FONT} fontWeight={900} fontSize={30} fill="#1e4a66" textAnchor="middle" letterSpacing={4} transform="rotate(-24 330 620)">TANDUK EMAS</text>
        <text x={1010} y={420} fontFamily={FONT} fontWeight={900} fontSize={38} fill="#17425e" textAnchor="middle" letterSpacing={4}>BOSPORUS</text>
        <text x={560} y={420} fontFamily={FONT} fontWeight={900} fontSize={34} fill="#4a2c14" textAnchor="middle" letterSpacing={3}>GALATA</text>
        {/* Byzantine chain */}
        <g transform={`scale(${chainPulse} 1) translate(${-736 * (chainPulse - 1) / chainPulse} 0)`}>
          {links.map((l, i) => (<ellipse key={i} cx={l.x} cy={l.y} rx={9} ry={6} fill="#8a8f99" stroke={INK} strokeWidth={3} />))}
        </g>
        <text x={700} y={720} fontFamily={FONT} fontWeight={900} fontSize={30} fill="#5a2f8e" textAnchor="middle" letterSpacing={2}>RANTAI</text>
        {/* Byzantine ships behind chain */}
        {[0, 1, 2].map((i) => (<g key={i} transform={`translate(${620 - i * 70} ${790 + i * 6})`}><path d="M-26 0 Q0 18 26 0 L20 -10 L-20 -10Z" fill="#5a2f8e" stroke={INK} strokeWidth={3} /></g>))}
        {/* Ottoman fleet blocked in Bosphorus */}
        {[0, 1, 2, 3].map((i) => (
          <g key={i} transform={`translate(${900 + (i % 2) * 50} ${620 + i * 44 + Math.sin(f * 0.15 + i) * 4})`}>
            <path d="M-30 0 Q0 20 30 0 L22 -12 L-22 -12Z" fill="#b3202a" stroke={INK} strokeWidth={3} />
            <line x1={0} y1={-12} x2={0} y2={-38} stroke={INK} strokeWidth={3} />
          </g>
        ))}
        {f < 40 && <g stroke="#b3202a" strokeWidth={12} strokeLinecap="round"><line x1={760} y1={760} x2={790} y2={790} /><line x1={790} y1={760} x2={760} y2={790} /></g>}
        {/* the unexpected route over land */}
        <path d={`M${ROUTE[0][0]} ${ROUTE[0][1]} C${ROUTE[1][0]} ${ROUTE[1][1]} ${ROUTE[2][0]} ${ROUTE[2][1]} ${ROUTE[3][0]} ${ROUTE[3][1]}`} fill="none" stroke="#b3202a" strokeWidth={9} strokeLinecap="round" strokeDasharray={`${route * 560} 2000`} opacity={route > 0 ? 1 : 0} />
        {route > 0 && (
          <g transform={`translate(${pos.x} ${pos.y})`}>
            <path d="M-34 0 Q0 22 34 0 L24 -14 L-24 -14Z" fill="#b3202a" stroke={INK} strokeWidth={4} />
            <line x1={0} y1={-14} x2={0} y2={-52} stroke={INK} strokeWidth={4} />
            <path d="M0 -50 Q22 -34 0 -20Z" fill="#f4ead2" stroke={INK} strokeWidth={3} />
          </g>
        )}
      </Camera>
      <Tag text="TANDUK EMAS" top={170} from={4} to={90} />
    </AbsoluteFill>
  );
};

const Overhead: React.FC = () => {
  const f = useCurrentFrame();
  const sy = f * 7;
  const crew = Array.from({length: 18}).map((_, i) => ({side: i % 2 ? 1 : -1, row: Math.floor(i / 2)}));
  return (
    <AbsoluteFill>
      <Camera keys={[{f: 0, x: 540, y: 500, z: 1.0, r: 0}, {f: 50, x: 540, y: 1000, z: 1.3, r: 2}]}>
        <rect x={-800} y={-800} width={2800} height={4400} fill="#86a354" />
        {Array.from({length: 40}).map((_, i) => (<rect key={i} x={-800 + i * 70} y={-800} width={30} height={4400} fill="#7a984c" opacity={0.6} />))}
        <rect x={380} y={-800} width={320} height={4400} fill="#b99262" stroke={INK} strokeWidth={6} />
        {Array.from({length: 120}).map((_, i) => (<rect key={i} x={410} y={-800 + i * 40 + (sy % 40)} width={260} height={14} fill="#6b4423" />))}
        <rect x={430} y={-800} width={30} height={4400} fill="#fff4cf" opacity={0.28} />
        <rect x={620} y={-800} width={30} height={4400} fill="#fff4cf" opacity={0.28} />
        {/* ships moving on greased rails (top-down) */}
        {[0, 1].map((k) => {
          const y = 150 + k * 700 + sy * 0.9;
          return (
            <g key={k} transform={`translate(540 ${y})`}>
              <path d="M0 -300 C100 -200 100 150 0 300 C-100 150 -100 -200 0 -300Z" fill="#7a4a28" stroke={INK} strokeWidth={7} />
              <path d="M0 -270 L0 270" stroke="#4a2c14" strokeWidth={6} />
              {Array.from({length: 7}).map((_, i) => (<line key={i} x1={-76} y1={-190 + i * 62} x2={76} y2={-190 + i * 62} stroke="#4a2c14" strokeWidth={5} />))}
              <circle cx={0} cy={-40} r={16} fill="#5b3a1c" stroke={INK} strokeWidth={4} />
              <rect x={-120} y={-52} width={240} height={26} rx={10} fill="#f4ead2" stroke={INK} strokeWidth={4} />
              <path d="M0 330 l-30 -50 h60Z" fill="#b3202a" stroke={INK} strokeWidth={4} />
            </g>
          );
        })}
        {/* crew pulling ropes */}
        {crew.map((c, i) => {
          const y = 520 + c.row * 100 + sy * 0.9 - 330;
          const x = 540 + c.side * (250 + (c.row % 2) * 40);
          return (
            <g key={i}>
              <line x1={540} y1={y + 330 - 120} x2={x} y2={y + 20} stroke="#7a5a32" strokeWidth={5} />
              <ellipse cx={x} cy={y + 20} rx={30} ry={16} fill="#c4502f" stroke={INK} strokeWidth={4} />
              <circle cx={x} cy={y + 10 + Math.sin(f * 0.5 + i) * 3} r={20} fill="#fbf8f1" stroke={INK} strokeWidth={4} />
              <ellipse cx={x} cy={y + 8} rx={21} ry={10} fill="#f4eede" stroke={INK} strokeWidth={3} />
            </g>
          );
        })}
      </Camera>
    </AbsoluteFill>
  );
};

const SIDE_SPLASH = 70;
const Tracking: React.FC = () => {
  const f = useCurrentFrame();
  const shipX = 300 + f * 17;
  const water = shipX > 1450;
  const sink = water ? Math.min(40, (shipX - 1450) * 0.35) : 0;
  const groundY = (x: number) => (x < 1500 ? 1420 : 1420 + Math.min(120, (x - 1500) * 0.45));
  return (
    <AbsoluteFill>
      <Camera keys={[{f: 0, x: 760, y: 1220, z: 1.25}, {f: 80, x: 1620, y: 1230, z: 1.25}]}>
        <Sky id="sky4" top={-200} bottom={1500} stops={[[0, '#4f84d0'], [0.72, '#9cc7ee'], [1, '#f3dcb0']]} />
        <Parallax depth={0.25}><Clouds y={420} n={6} seed={21} speed={0.5} scale={1.2} /></Parallax>
        <Parallax depth={0.5}><Hills y={1100} amp={60} color="#a9b6c6" seed={31} /></Parallax>
        <Parallax depth={0.75}><Hills y={1250} amp={44} color="#86a15a" seed={41} shade="#2d4a1f" /></Parallax>
        <Ground y={1420} color="#c9a86a" x1={1600} />
        <Water x0={1500} x1={3600} y0={1540} y1={1900} color="#3f86b8" />
        <polygon points="1500,1420 1640,1540 1640,1900 1500,1900" fill="#b0905a" />
        {/* wooden track */}
        <rect x={-600} y={1418} width={1160 + 1000} height={20} fill="url(#plank)" stroke={INK} strokeWidth={4} />
        {Array.from({length: 40}).map((_, i) => (<line key={i} x1={-600 + i * 60 + 30} y1={1412} x2={-600 + i * 60 + 30} y2={1442} stroke="#5e3a1c" strokeWidth={6} />))}
        <rect x={-600} y={1414} width={2200} height={6} fill="#fff4cf" opacity={0.5} />
        <Ship x={shipX} y={groundY(shipX) - 56} s={1.15} rock={Math.sin(f * 0.3) * 1.2} sinkY={sink} />
        {/* soldiers hauling in front */}
        {[0, 1, 2, 3].map((i) => (
          <Character key={i} costume="ottoman" x={shipX + 470 + i * 150} y={groundY(shipX + 470 + i * 150) + 120} scale={0.95} pose="haul" item="rope" mood={i % 2 ? 'shout' : 'determined'} variant={i % 2} speed={1.2} offset={i * 5} />
        ))}
        {[0, 1].map((i) => (
          <Character key={'p' + i} costume="ottoman" x={shipX - 330 - i * 150} y={groundY(shipX - 330 - i * 150) + 120} scale={0.95} pose="haul" flip mood="shout" speed={1.2} offset={i * 7 + 2} />
        ))}
        <Dust y0={1100} y1={1500} n={20} speed={5} />
        {f >= SIDE_SPLASH && (
          <g>
            <Debris x={1560} y={1520} start={SIDE_SPLASH} dur={50} count={26} power={20} color="#cfe9f7" seed="spl" sizeMin={6} sizeMax={14} ground={1560} />
            <Puffs x={1540} y={1520} start={SIDE_SPLASH} dur={60} count={18} spread={400} rise={160} size={46} color="#e9f6fc" opacity={0.85} seed="spp" />
          </g>
        )}
      </Camera>
    </AbsoluteFill>
  );
};

/** SCENE 4 - map, overhead shot, tracking shot. */
export const Ships: React.FC = () => (
  <AbsoluteFill>
    <Sequence from={0} durationInFrames={104}><MapShot /></Sequence>
    <Sequence from={94} durationInFrames={61}><FadeIn><Overhead /></FadeIn></Sequence>
    <Sequence from={145} durationInFrames={90}><FadeIn><Tracking /></FadeIn></Sequence>
  </AbsoluteFill>
);
