import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {Camera, Parallax} from '../components/Camera';
import {City, Clouds, Ground, Hills, Sky, Tents} from '../components/Background';
import {Character} from '../components/Character';
import {Army} from '../components/Soldier';
import {Dust} from '../components/ParticleSystem';
import {Flag} from '../components/Flag';
import {Tag} from '../components/AnimatedText';

/** SCENE 2 - Ottoman camp; low-angle reveal of Mehmed II pointing at the city. */
export const Sultan: React.FC = () => {
  const f = useCurrentFrame();
  const pose = f < 40 ? 'hip' : f < 85 ? 'raise' : 'point';
  const mood = f < 40 ? 'smug' : 'smug';
  return (
    <AbsoluteFill>
      <Camera keys={[{f: 0, x: 440, y: 1400, z: 1.75, r: -5}, {f: 90, x: 520, y: 1230, z: 1.35, r: -2}, {f: 225, x: 590, y: 1010, z: 1.0, r: 0}]}>
        <Sky id="sky2" top={-200} bottom={1500} stops={[[0, '#4f84d0'], [0.72, '#9cc7ee'], [1, '#f3dcb0']]} />
        <Parallax depth={0.2}><Clouds y={420} n={5} seed={4} speed={0.6} scale={1.3} /></Parallax>
        <Parallax depth={0.45}>
          <Hills y={1090} amp={40} color="#a6b4c6" seed={5} />
          <City x={930} y={1040} s={0.55} haze={0.6} hazeColor="#cfdcec" topper="cross" flags="byz" />
        </Parallax>
        <Parallax depth={0.7}>
          <Hills y={1180} amp={50} color="#86a15a" seed={9} shade="#2d4a1f" />
          <Tents x={-100} y={1190} s={0.5} n={6} seed={2} gap={330} />
          <Army x0={-100} x1={1300} yFar={1180} yNear={1230} rows={2} cols={16} seed={3} />
        </Parallax>
        <Parallax depth={0.88}>
          <Ground y={1250} color="#c9a86a" accent="#8d9b4a" />
          <Army x0={-200} x1={1400} yFar={1290} yNear={1420} rows={3} cols={13} seed={8} />
          {[80, 330, 640, 960].map((fx, i) => (<Flag key={fx} x={fx} y={1040 + (i % 2) * 40} w={140} h={90} color="#b3202a" emblem="crescent" pole={260} seed={i * 3} />))}
        </Parallax>
        <Parallax depth={1.0}>
          <Army x0={-300} x1={1500} yFar={1450} yNear={1560} rows={2} cols={9} seed={11} />
        </Parallax>
        <Character costume="ottoman" x={780} y={1585} scale={1.15} item="flag" mood="shout" pose="idle" variant={1} offset={3} />
        <Character costume="ottoman" x={1010} y={1610} scale={1.2} item="shield-spear" mood="determined" offset={9} />
        <Character costume="mehmed" x={380} y={1620} scale={1.55} mood={mood} pose={pose} talk={f > 85} look={0.7} />
        <Dust y0={900} y1={1700} n={30} color="#ffe9b8" speed={4} />
      </Camera>
      <Tag text="MEHMED II" top={150} from={60} to={215} />
    </AbsoluteFill>
  );
};
