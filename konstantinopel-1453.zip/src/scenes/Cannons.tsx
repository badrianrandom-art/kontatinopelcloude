import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {Camera, Parallax} from '../components/Camera';
import {Clouds, Ground, Hills, Sky, Tower, Wall} from '../components/Background';
import {Character} from '../components/Character';
import {Cannon, Cannonball, Crate, Barrel} from '../components/Props';
import {Debris, Dust, Flash, Puffs} from '../components/ParticleSystem';
import {ease} from '../theme';
import timing from '../timing.json';

const START = timing.scenes.cannons[0];
const L = (t: number) => Math.round((t - START) * 30);
const BOOM1 = L(timing.events.cannonBoom), HIT1 = L(timing.events.cannonImpact), FUSE = L(timing.events.cannonFuse);
const BOOM2 = L(timing.events.cannonBoom2), HIT2 = L(timing.events.cannonImpact2);

const CX = 520, CY = 1500, MUZ = {x: CX + 292, y: CY - 106};
const HIT1P = {x: 1930, y: 1290}, HIT2P = {x: 2010, y: 1180};

const arc = (f: number, a: number, b: number, p0: {x: number; y: number}, p1: {x: number; y: number}, lift: number) => {
  const t = ease(f, a, b, 0, 1, (x) => x);
  return {t, x: p0.x + (p1.x - p0.x) * t, y: p0.y + (p1.y - p0.y) * t - lift * Math.sin(Math.PI * t)};
};

/** SCENE 3 - giant bombard fires at the walls. */
export const Cannons: React.FC = () => {
  const f = useCurrentFrame();
  const rec = (b: number) => (f >= b ? -70 * Math.exp(-(f - b) / 14) : 0);
  const recoil = rec(BOOM1) + rec(BOOM2);
  const b1 = arc(f, BOOM1, HIT1, MUZ, HIT1P, 230);
  const b2 = arc(f, BOOM2, HIT2, MUZ, HIT2P, 200);
  const crack = ease(f, HIT1, HIT1 + 40, 0, 0.7) + ease(f, HIT2, HIT2 + 45, 0, 0.3);
  const wallJit = (f > HIT1 && f < HIT1 + 14 ? Math.sin(f * 2.7) * 6 : 0) + (f > HIT2 && f < HIT2 + 16 ? Math.sin(f * 3.1) * 8 : 0);
  const fuseLeft = ease(f, FUSE, BOOM1, 1, 0, (x) => x);
  const torchHand = f < FUSE - 12 ? 'march' : 'idle';
  return (
    <AbsoluteFill>
      <Camera
        keys={[
          {f: 0, x: 620, y: 1170, z: 1.0}, {f: FUSE - 10, x: 520, y: 1290, z: 1.3}, {f: BOOM1 + 6, x: 660, y: 1330, z: 1.35},
          {f: HIT1 - 14, x: 1500, y: 1280, z: 1.15}, {f: HIT1 + 6, x: 1860, y: 1220, z: 1.5}, {f: BOOM2 - 6, x: 1800, y: 1200, z: 1.25},
          {f: HIT2 + 20, x: 1930, y: 1180, z: 1.6}, {f: 300, x: 1800, y: 1200, z: 1.2},
        ]}
        shakes={[{at: BOOM1, dur: 28, amp: 26}, {at: HIT1, dur: 40, amp: 36}, {at: BOOM2, dur: 22, amp: 20}, {at: HIT2, dur: 46, amp: 40}]}
      >
        <Sky id="sky3" top={-200} bottom={1500} stops={[[0, '#4f84d0'], [0.72, '#9cc7ee'], [1, '#f3dcb0']]} />
        <Parallax depth={0.2}><Clouds y={450} n={6} seed={11} speed={0.5} scale={1.3} /></Parallax>
        <Parallax depth={0.5}><Hills y={1120} amp={50} color="#a8b5c7" seed={2} /></Parallax>
        <Parallax depth={0.8}><Hills y={1230} amp={44} color="#8aa55c" seed={6} shade="#2d4a1f" /></Parallax>
        <Ground y={1470} color="#cfae72" />
        {/* Byzantine walls (target) */}
        <Wall x={1780} y={1500} w={900} h={420} crack={Math.min(1, crack)} crackX={1940} jitter={wallJit} breach={ease(f, HIT2 + 20, 290, 0, 0.35)} breachX={2060} />
        <Tower x={1700} y={1500} w={150} h={520} roof="#7d2f3a" flag={{color: '#5a2f8e', emblem: 'cross'}} />
        <Character costume="byzantine" x={2220} y={1090} scale={0.7} flip item="spear" mood={f > HIT1 ? 'worry' : 'determined'} offset={6} />
        <Character costume="byzantine" x={2400} y={1090} scale={0.7} flip item="shield-spear" mood={f > HIT1 ? 'shout' : 'determined'} offset={14} />
        {/* Ottoman battery */}
        <Barrel x={120} y={1520} s={1.2} /><Crate x={90} y={1590} s={1.1} /><Crate x={880} y={1580} s={1.0} />
        <Cannon x={CX} y={CY} s={1} recoil={recoil} />
        {f >= FUSE && f < BOOM1 && (
          <g>
            <path d={`M${CX - 232} ${CY - 156} q-30 -6 ${-40 * fuseLeft} ${30 * fuseLeft}`} stroke="#3a2a22" strokeWidth={5} fill="none" />
            <circle cx={CX - 232 - 40 * fuseLeft} cy={CY - 156 + 30 * fuseLeft} r={10 + 4 * Math.sin(f * 2)} fill="#ffd25a" stroke="#f07a1a" strokeWidth={4} />
          </g>
        )}
        <Character costume="ottoman" x={225} y={1585} scale={1.05} mood={f > BOOM1 ? 'awe' : 'determined'} pose={torchHand} item={f < BOOM1 + 20 ? 'torch' : 'none'} variant={1} look={0.5} />
        <Character costume="ottoman" x={640} y={1612} scale={1.0} mood={f > BOOM1 ? 'shout' : 'serious'} pose={f < FUSE ? 'haul' : 'cheer'} offset={7} look={0.6} />
        <Character costume="ottoman" x={790} y={1625} scale={1.0} mood="determined" pose={f < BOOM1 ? 'idle' : 'cheer'} item="sword" offset={15} flip />
        {/* muzzle blast */}
        <Flash start={BOOM1} dur={10} />
        <Flash start={BOOM2} dur={8} peak={0.6} />
        <Puffs x={MUZ.x + 20} y={MUZ.y} start={BOOM1} dur={90} count={18} spread={260} rise={220} size={52} color="#cfc6b6" seed="m1" drift={120} />
        <Puffs x={MUZ.x + 20} y={MUZ.y} start={BOOM2} dur={80} count={14} spread={240} rise={200} size={48} color="#cfc6b6" seed="m2" drift={110} />
        <Puffs x={CX - 200} y={CY - 150} start={BOOM1} dur={70} count={8} spread={120} rise={120} size={30} color="#8a8478" seed="m3" />
        {/* flying ball */}
        {f >= BOOM1 && f < HIT1 && (
          <g>
            {[1, 2, 3, 4, 5].map((k) => {
              const tt = Math.max(0, b1.t - k * 0.035);
              return <circle key={k} cx={MUZ.x + (HIT1P.x - MUZ.x) * tt} cy={MUZ.y + (HIT1P.y - MUZ.y) * tt - 230 * Math.sin(Math.PI * tt)} r={24 - k * 3} fill="#dcd5c8" opacity={0.6 - k * 0.1} />;
            })}
            <Cannonball x={b1.x} y={b1.y} />
          </g>
        )}
        {f >= BOOM2 && f < HIT2 && (
          <g>
            {[1, 2, 3, 4].map((k) => {
              const tt = Math.max(0, b2.t - k * 0.035);
              return <circle key={k} cx={MUZ.x + (HIT2P.x - MUZ.x) * tt} cy={MUZ.y + (HIT2P.y - MUZ.y) * tt - 200 * Math.sin(Math.PI * tt)} r={22 - k * 3} fill="#dcd5c8" opacity={0.6 - k * 0.12} />;
            })}
            <Cannonball x={b2.x} y={b2.y} r={26} />
          </g>
        )}
        {/* impacts */}
        <Flash start={HIT1} dur={7} peak={0.5} color="#ffe2a0" />
        <Debris x={HIT1P.x} y={HIT1P.y} start={HIT1} dur={70} count={24} power={24} ground={1500} seed="i1" />
        <Puffs x={HIT1P.x} y={HIT1P.y + 40} start={HIT1} dur={110} count={22} spread={380} rise={300} size={62} color="#c8b896" seed="i1p" />
        <Puffs x={HIT1P.x} y={HIT1P.y} start={HIT1 + 4} dur={110} count={12} spread={300} rise={360} size={56} color="#5c5a5c" opacity={0.7} seed="i1s" drift={-60} />
        <Flash start={HIT2} dur={7} peak={0.55} color="#ffe2a0" />
        <Debris x={HIT2P.x} y={HIT2P.y} start={HIT2} dur={70} count={30} power={28} ground={1500} seed="i2" sizeMax={36} />
        <Puffs x={HIT2P.x} y={HIT2P.y + 60} start={HIT2} dur={110} count={26} spread={460} rise={340} size={70} color="#c8b896" seed="i2p" />
        <Puffs x={HIT2P.x} y={HIT2P.y} start={HIT2 + 4} dur={90} count={14} spread={340} rise={400} size={60} color="#5c5a5c" opacity={0.7} seed="i2s" drift={-80} />
        <Dust y0={900} y1={1600} n={20} speed={2} />
      </Camera>
    </AbsoluteFill>
  );
};
