import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {Camera, Parallax} from '../components/Camera';
import {Birds, City, Clouds, Hills, Sky, Sun, Water} from '../components/Background';
import {Dust} from '../components/ParticleSystem';
import {BlackFade} from '../components/Transitions';
import {TitleBlock} from '../components/AnimatedText';
import {ease} from '../theme';

/** SCENE 7 - sunrise over Constantinople, final title, fade-out. */
export const Ending: React.FC = () => {
  const f = useCurrentFrame();
  const sunY = ease(f, 0, 200, 1100, 830);
  return (
    <AbsoluteFill>
      <Camera keys={[{f: 0, x: 540, y: 1150, z: 1.35}, {f: 240, x: 540, y: 900, z: 1.0}]}>
        <Sky id="sky7" top={-200} bottom={1200} stops={[[0, '#5a7fc4'], [0.5, '#f2a47a'], [1, '#ffd89a']]} />
        <Parallax depth={0.1}><Sun x={150} y={sunY} r={95} /></Parallax>
        <Parallax depth={0.2}><Clouds y={420} n={5} seed={61} speed={0.4} scale={1.3} tint="#f2b48e" /><Clouds y={760} n={3} seed={62} speed={0.7} scale={0.8} tint="#f2b48e" opacity={0.9} /></Parallax>
        <Parallax depth={0.3}><Birds y={600} n={7} /></Parallax>
        <Parallax depth={0.5}><Hills y={1140} amp={40} color="#b7a9b8" seed={71} /></Parallax>
        <Parallax depth={0.7}><City x={560} y={1290} s={1.3} haze={0.22} hazeColor="#f3c0a0" topper="none" flags="ottoman" /></Parallax>
        <Water x0={-1600} x1={3600} y0={1290} y1={2200} color="#3b6ea5" light="#ffd9a0" />
        <ellipse cx={150} cy={1480} rx={60} ry={280} fill="#ffe9b0" opacity={0.28} />
        <Dust y0={700} y1={1300} n={22} speed={2} />
      </Camera>
      <TitleBlock top={250} lines={[
        {text: 'THE FALL OF', size: 84, delay: 60, spacing: 12},
        {text: 'CONSTANTINOPLE', size: 98, delay: 78, spacing: 6},
        {text: '1453', size: 190, delay: 100, color: '#e8b83a', spacing: 14},
      ]} />
      <BlackFade from={212} to={239} />
    </AbsoluteFill>
  );
};
