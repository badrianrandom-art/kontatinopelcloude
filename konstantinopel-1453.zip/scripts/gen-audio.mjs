// Procedural audio (100% offline, no paid services).
// Writes public/audio/music.wav (score + wind + crowd ambience) and public/audio/sfx.wav
// (cannons, impacts, footsteps, steel clashes, whooshes). Timings come from src/timing.json.
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const T = JSON.parse(fs.readFileSync(path.join(here, '../src/timing.json'), 'utf8'));
const outDir = path.join(here, '../public/audio');
fs.mkdirSync(outDir, {recursive: true});
if (fs.existsSync(path.join(outDir, 'music.wav')) && fs.existsSync(path.join(outDir, 'sfx.wav')) && !process.env.FORCE_AUDIO) {
  console.log('[audio] music.wav & sfx.wav sudah ada (set FORCE_AUDIO=1 untuk generate ulang)');
  process.exit(0);
}

const SR = 44100;
const N = SR * T.durationSec;
const music = new Float32Array(N);
const sfx = new Float32Array(N);
let seed = 20240529;
const rnd = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return (seed / 4294967296) * 2 - 1; };
const TAU = Math.PI * 2;
const sm = (x) => { x = Math.min(1, Math.max(0, x)); return x * x * (3 - 2 * x); };

function add(buf, t0, len, fn, gain = 1) {
  const i0 = Math.max(0, Math.floor(t0 * SR));
  const i1 = Math.min(N, Math.floor((t0 + len) * SR));
  for (let i = i0; i < i1; i++) buf[i] += fn((i - i0) / SR, (i - i0) / (i1 - i0)) * gain;
}

// ---------- MUSIC ----------
const chords = [
  [73.42, 110.0, 146.83, 174.61],  // Dm
  [58.27, 87.31, 116.54, 146.83],  // Bb
  [65.41, 98.0, 130.81, 155.56],   // Cm-ish
  [55.0, 82.41, 110.0, 138.59],    // A (phrygian dominant colour)
];
const seg = 7.5;
for (let s = 0; s < 8; s++) {
  const c = chords[s % 4];
  const t0 = s * seg - 1.5, len = seg + 3;
  for (const f of c) {
    add(music, t0, len, (t, u) => {
      const env = sm(t / 1.5) * sm((len - t) / 1.5);
      const lfo = 1 + 0.004 * Math.sin(TAU * 0.2 * t + f);
      const x = Math.sin(TAU * f * lfo * t) + 0.5 * Math.sin(TAU * 2 * f * t + 1) + 0.25 * Math.sin(TAU * 3 * f * t + 2);
      return x * env * 0.045;
    });
  }
}
// duduk-like melody (D phrygian dominant)
const D4 = 293.66, Eb = 311.13, Fs = 369.99, G = 392, A = 440, Bb = 466.16, C5 = 523.25;
const mel = [
  [1.0, D4, 2.2], [3.4, Eb, 1.0], [4.5, Fs, 2.0], [6.6, G, 1.2], [8.2, A, 2.4], [10.8, Bb, 1.2], [12.2, A, 1.0], [13.4, G, 2.0],
  [16.0, D4, 1.2], [17.4, Fs, 1.2], [18.8, G, 1.6], [20.6, A, 2.6], [23.4, Bb, 1.4], [25.0, C5, 2.4], [27.6, Bb, 1.2], [29.0, A, 1.4], [30.6, G, 2.2],
  [33.4, A, 0.9], [34.4, Bb, 0.9], [35.4, C5, 1.2], [36.8, Bb, 0.8], [37.8, A, 1.4], [39.4, G, 1.6], [41.2, Fs, 1.4], [42.8, Eb, 1.4], [44.4, D4, 3.4],
  [48.6, A, 2.0], [51.0, Bb, 1.8], [53.2, A, 1.4], [54.8, G, 1.8], [56.8, Fs, 1.6], [58.2, D4, 1.8],
];
for (const [t0, f, d] of mel) {
  add(music, t0, d + 0.5, (t) => {
    const env = sm(t / 0.18) * sm((d + 0.5 - t) / 0.5);
    const vib = 1 + 0.006 * Math.sin(TAU * 5.3 * t) * sm(t / 0.5);
    const br = rnd() * 0.05;
    const ph = TAU * f * vib * t;
    return (Math.sin(ph) + 0.45 * Math.sin(2 * ph) + 0.2 * Math.sin(3 * ph) + br) * env * 0.07;
  });
}
// war drums
const thump = (buf, t, vel = 1, f0 = 95) => add(buf, t, 0.7, (x) => {
  const fr = f0 * Math.exp(-x * 9) + 42;
  return (Math.sin(TAU * fr * x) * Math.exp(-x * 6) + rnd() * 0.15 * Math.exp(-x * 60)) * vel;
}, 0.55);
const drumZones = [[8.0, 33.0, 0.75, 0.55], [33.0, 40.0, 0.4, 0.8], [40.0, 47.0, 0.62, 0.6], [53.5, 59.0, 1.5, 0.35]];
for (const [a, b, step, vel] of drumZones) {
  let k = 0;
  for (let t = a; t < b; t += step, k++) {
    thump(music, t, vel * (k % 4 === 0 ? 1 : 0.7));
    if (k % 2 === 1) thump(music, t + step / 2, vel * 0.35, 130);
  }
}
// wind (low-passed noise, slow gusts) + crowd murmur (band-passed)
let w1 = 0, c1 = 0, c2 = 0;
for (let i = 0; i < N; i++) {
  const t = i / SR;
  const n = rnd();
  w1 += 0.012 * (n - w1);
  const gust = 0.55 + 0.45 * Math.sin(TAU * 0.11 * t + 1.3);
  const wideZone = (t < 8 || t > 52) ? 1.6 : 1;
  music[i] += w1 * gust * 0.5 * wideZone;
  c1 += 0.12 * (n - c1); c2 += 0.02 * (n - c2);
  const band = c1 - c2;
  const crowdOn = (t > 8 && t < 16) || (t > 33 && t < 52) ? 1 : 0;
  music[i] += band * crowdOn * (0.35 + 0.25 * Math.sin(TAU * 3.1 * t)) * 0.28;
}

// ---------- SFX ----------
function cannon(t, big = 1) {
  add(sfx, t, 2.2, (x) => Math.sin(TAU * (140 * Math.exp(-x * 3.2) + 28) * x) * Math.exp(-x * 2.2), 0.95 * big);
  let lp = 0;
  add(sfx, t, 1.2, (x) => { lp += 0.08 * (rnd() - lp); return lp * Math.exp(-x * 3.5) * 9; }, 0.8 * big);
  add(sfx, t, 0.05, () => rnd(), 0.6 * big);
}
function impact(t, big = 1) {
  add(sfx, t, 1.6, (x) => Math.sin(TAU * (70 * Math.exp(-x * 2) + 32) * x) * Math.exp(-x * 2.6), 0.9 * big);
  let lp = 0;
  add(sfx, t, 1.0, (x) => { lp += 0.15 * (rnd() - lp); return lp * Math.exp(-x * 4) * 6; }, 0.7 * big);
  for (let k = 0; k < 14; k++) {
    const tt = t + 0.1 + Math.abs(rnd()) * 1.1;
    add(sfx, tt, 0.06, (x) => Math.sin(TAU * (900 + 900 * Math.abs(rnd())) * x) * Math.exp(-x * 60), 0.12);
  }
}
function fuse(a, b) {
  let hp = 0;
  add(sfx, a, b - a, (x) => { const n = rnd(); const y = n - hp; hp += 0.5 * (n - hp); return y * (Math.abs(rnd()) > 0.55 ? 1 : 0.2); }, 0.07);
}
function step(t, v = 1) {
  let lp = 0;
  add(sfx, t, 0.09, (x) => { lp += 0.2 * (rnd() - lp); return lp * Math.exp(-x * 45) * 8; }, 0.35 * v);
}
function clash(t, v = 1) {
  const fs_ = [1180, 1830, 2760, 3500];
  add(sfx, t, 0.5, (x) => fs_.reduce((s, f, k) => s + Math.sin(TAU * f * x + k) * Math.exp(-x * (14 + k * 6)), 0) * 0.25, 0.5 * v);
  add(sfx, t, 0.04, () => rnd(), 0.4 * v);
}
function whoosh(t, len = 0.9, v = 1) {
  let lp = 0;
  add(sfx, t, len, (x, u) => { lp += (0.02 + 0.25 * u) * (rnd() - lp); return lp * Math.sin(Math.PI * u) * 7; }, 0.35 * v);
}
const E = T.events;
fuse(E.cannonFuse, E.cannonBoom);
cannon(E.cannonBoom, 1); impact(E.cannonImpact, 1);
cannon(E.cannonBoom2, 0.9); impact(E.cannonImpact2, 1.1);
whoosh(E.cannonBoom + 0.1, 1.0, 0.8); whoosh(E.cannonBoom2 + 0.1, 0.9, 0.7);
// ships: ropes creak + splash
for (let t = 29.0; t < E.shipSplash; t += 0.4) step(t, 0.7);
add(sfx, E.shipSplash, 1.4, (x) => { let lp = 0; return (rnd() * Math.exp(-x * 3) + Math.sin(TAU * 90 * x) * Math.exp(-x * 5) * 0.6); }, 0.45);
// assault: running footsteps + clashes + blast
for (let t = 33.3; t < 38.2; t += 0.17) step(t, 0.8 + 0.2 * Math.abs(rnd()));
T.events.assaultClash.forEach((t, i) => clash(t, 0.8 + 0.1 * (i % 3)));
for (let t = 34.8; t < 38.0; t += 0.43) clash(t + 0.05 * Math.abs(rnd()), 0.35);
impact(E.assaultBlast, 1.0); whoosh(E.assaultBlast - 0.5, 0.6, 0.6);
// conquest: collapse rumble, marching, flag whoosh
impact(E.wallFall, 1.2);
for (let t = 40.4; t < 46.0; t += 0.32) step(t, 0.55);
whoosh(E.flagRaise, 1.6, 0.9);
add(sfx, 41.5, 1.8, (x, u) => Math.sin(TAU * 196 * x) * Math.sin(Math.PI * u) * 0.5 + Math.sin(TAU * 294 * x) * Math.sin(Math.PI * u) * 0.3, 0.12); // horn
// ending title hit
impact(E.titleHit, 0.8);

// ---------- MASTER ----------
function master(buf, target, fadeOut = 3) {
  let peak = 0;
  for (let i = 0; i < N; i++) { buf[i] = Math.tanh(buf[i] * 1.2); peak = Math.max(peak, Math.abs(buf[i])); }
  const g = target / (peak || 1);
  for (let i = 0; i < N; i++) {
    const t = i / SR;
    const fi = sm(t / 0.6), fo = sm((T.durationSec - t) / fadeOut);
    buf[i] *= g * fi * fo;
  }
}
master(music, 0.85, 3.5);
master(sfx, 0.9, 0.5);

function writeWav(file, buf) {
  const data = Buffer.alloc(44 + N * 2);
  data.write('RIFF', 0); data.writeUInt32LE(36 + N * 2, 4); data.write('WAVE', 8);
  data.write('fmt ', 12); data.writeUInt32LE(16, 16); data.writeUInt16LE(1, 20); data.writeUInt16LE(1, 22);
  data.writeUInt32LE(SR, 24); data.writeUInt32LE(SR * 2, 28); data.writeUInt16LE(2, 32); data.writeUInt16LE(16, 34);
  data.write('data', 36); data.writeUInt32LE(N * 2, 40);
  for (let i = 0; i < N; i++) data.writeInt16LE(Math.max(-32768, Math.min(32767, Math.round(buf[i] * 32767))), 44 + i * 2);
  fs.writeFileSync(file, data);
  console.log('[audio] wrote', path.relative(process.cwd(), file));
}
writeWav(path.join(outDir, 'music.wav'), music);
writeWav(path.join(outDir, 'sfx.wav'), sfx);
